import React from "react";
import PageHeader from "../components/common/PageHeader";
import { Construction } from "lucide-react";

export default function PlaceholderPage({ title, subtitle }) {
  return (
    <div className="space-y-6">
      <PageHeader title={title} subtitle={subtitle} />
      <div className="border border-dashed border-[#27272A] rounded-sm p-16 text-center">
        <div className="w-14 h-14 mx-auto flex items-center justify-center bg-[#141414] border border-[#27272A] rounded-sm mb-4">
          <Construction className="w-6 h-6 text-[#E50914]" />
        </div>
        <div className="font-display uppercase tracking-widest text-white text-xl">Coming Soon</div>
        <p className="text-sm text-zinc-500 mt-2 max-w-md mx-auto">
          This module is on the roadmap for Phase 2. The API endpoints and data models are already wired — the UI is in production design review.
        </p>
      </div>
    </div>
  );
}

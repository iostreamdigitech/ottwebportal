import React, { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "../../components/ui/input-otp";
import { ArrowLeft, ArrowRight, Zap } from "lucide-react";
import { toast } from "sonner";
import { authService } from "../../services";
import { AUTH } from "../../constants/testIds";

export default function OtpVerification() {
  const [params] = useSearchParams();
  const email = params.get("email") || "";
  const hint = params.get("hint");
  const nav = useNavigate();
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (otp.length !== 6) return toast.error("Enter the 6-digit OTP");
    setLoading(true);
    try {
      await authService.verifyOtp(email, otp);
      toast.success("Code verified");
      nav(`/reset-password?email=${encodeURIComponent(email)}&otp=${otp}`);
    } catch (err) {
      toast.error("Invalid OTP", { description: err?.detail });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white flex items-center justify-center p-6">
      <motion.form initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} onSubmit={submit} className="w-full max-w-md">
        <div className="flex items-center gap-2.5 mb-10">
          <div className="w-10 h-10 flex items-center justify-center bg-[#E50914] rounded-sm">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div className="font-display text-xl uppercase tracking-[0.25em]">CineStream</div>
        </div>
        <div className="text-[10px] uppercase tracking-[0.25em] text-[#E50914] font-semibold mb-3">— Verify OTP</div>
        <h2 className="font-display uppercase text-4xl tracking-tight leading-none mb-2">Enter the code</h2>
        <p className="text-zinc-500 text-sm mb-8">
          We sent a 6-digit code to <span className="text-white">{email || "your email"}</span>.
          {hint && <span className="block mt-1 text-amber-400">Demo hint: {hint}</span>}
        </p>

        <div className="flex justify-center" data-testid={AUTH.otpInput}>
          <InputOTP maxLength={6} value={otp} onChange={setOtp}>
            <InputOTPGroup>
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <InputOTPSlot
                  key={i}
                  index={i}
                  className="bg-[#141414] border-[#27272A] text-white w-12 h-14 text-xl"
                />
              ))}
            </InputOTPGroup>
          </InputOTP>
        </div>

        <button
          data-testid={AUTH.otpSubmit}
          disabled={loading}
          type="submit"
          className="mt-8 w-full h-12 bg-[#E50914] hover:bg-[#F40612] disabled:opacity-60 text-white font-semibold uppercase tracking-[0.2em] text-sm rounded-sm flex items-center justify-center gap-2"
        >
          {loading ? "Verifying…" : "Verify Code"} <ArrowRight className="w-4 h-4" />
        </button>
        <Link to="/login" className="mt-6 inline-flex items-center gap-2 text-xs text-zinc-500 hover:text-white uppercase tracking-[0.2em]">
          <ArrowLeft className="w-3 h-3" /> Back to sign in
        </Link>
      </motion.form>
    </div>
  );
}

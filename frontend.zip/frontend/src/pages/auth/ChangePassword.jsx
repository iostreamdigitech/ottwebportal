import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import PageHeader from "../../components/common/PageHeader";
import { authService } from "../../services";
import { AUTH } from "../../constants/testIds";

export default function ChangePassword() {
  const nav = useNavigate();
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (newPwd !== confirm) return toast.error("Passwords don't match");
    setLoading(true);
    try {
      await authService.changePassword(oldPwd, newPwd);
      toast.success("Password updated");
      nav("/dashboard");
    } catch (err) {
      toast.error("Update failed", { description: err?.detail });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl">
      <PageHeader title="Change Password" subtitle="Rotate your password regularly. Use a mix of upper, lower, digits and symbols." />
      <form onSubmit={submit} className="bg-[#141414] border border-[#27272A] rounded-sm p-6 space-y-5">
        <div>
          <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2">Old Password</label>
          <input data-testid={AUTH.changeOld} type="password" required value={oldPwd} onChange={(e) => setOldPwd(e.target.value)}
            className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none" />
        </div>
        <div>
          <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2">New Password</label>
          <input data-testid={AUTH.changeNew} type="password" required value={newPwd} onChange={(e) => setNewPwd(e.target.value)}
            className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none" />
        </div>
        <div>
          <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2">Confirm New Password</label>
          <input type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)}
            className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none" />
        </div>
        <button
          data-testid={AUTH.changeSubmit}
          disabled={loading}
          type="submit"
          className="h-11 bg-[#E50914] hover:bg-[#F40612] disabled:opacity-60 text-white font-semibold uppercase tracking-[0.2em] text-xs rounded-sm px-6"
        >
          {loading ? "Saving…" : "Update Password"}
        </button>
      </form>
    </div>
  );
}

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Zap, ArrowRight, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { authService } from "../../services";
import { useAuthStore } from "../../store/authStore";
import { AUTH } from "../../constants/testIds";

export default function Login() {
  const nav = useNavigate();
  const { setSession } = useAuthStore();
  const [email, setEmail] = useState("admin@ott.com");
  const [password, setPassword] = useState("Admin@123");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authService.loginnew({ email, password, remember });
      localStorage.setItem("ott_token", res.token);
      setSession({ token: res.token, user: res.user });
      toast.success("Welcome back", { description: res.user.name });
      nav("/dashboard");
    } catch (err) {
      toast.error("Login failed", { description: err?.detail || "Invalid credentials" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white grid lg:grid-cols-2 overflow-hidden">
      {/* Left: cinematic hero */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 overflow-hidden grain">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url(https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1600&q=80)",
          }}
        />
        <div className="absolute inset-0 cinema-vignette" />
        <div className="relative z-10 flex items-center gap-2.5">
          <div className="w-10 h-10 flex items-center justify-center bg-[#E50914] rounded-sm">
            <Zap className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <div>
            <div className="font-display text-xl uppercase tracking-[0.25em] leading-none">OTTONE</div>
            <div className="text-[10px] text-zinc-400 uppercase tracking-widest mt-1">Enterprise CMS</div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.6 }}
          className="relative z-10 max-w-lg"
        >
          <div className="mb-3 inline-flex items-center gap-2 border border-[#27272A] bg-black/50 backdrop-blur px-3 py-1 rounded-sm">
            <ShieldCheck className="w-3.5 h-3.5 text-[#E50914]" />
            <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-300">RSA + AES Encrypted Session</span>
          </div>
          <h1 className="font-display uppercase text-5xl xl:text-6xl leading-[0.9] tracking-tight">
            The nerve center<br />of your <span className="text-[#E50914]">streaming empire.</span>
          </h1>
          <p className="text-zinc-400 mt-5 max-w-md text-base leading-relaxed">
            Manage catalog, subscriptions, encoding, analytics and audiences across every screen — from a single, cinematic control room.
          </p>
        </motion.div>

        <div className="relative z-10 flex items-center gap-6 text-[10px] uppercase tracking-widest text-zinc-500">
          <span>© 2026 CineStream</span>
          <span>·</span>
          <span>All rights reserved</span>
        </div>
      </div>

      {/* Right: form */}
      <div className="flex items-center justify-center p-6 lg:p-12 relative">
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          onSubmit={submit}
          className="w-full max-w-md"
        >
          <div className="lg:hidden flex items-center gap-2.5 mb-8">
            <div className="w-10 h-10 flex items-center justify-center bg-[#E50914] rounded-sm">
              <Zap className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <div className="font-display text-xl uppercase tracking-[0.25em]">CineStream</div>
          </div>

          <div className="text-[10px] uppercase tracking-[0.25em] text-[#E50914] font-semibold mb-3">
            — Admin Sign In
          </div>
          <h2 className="font-display uppercase text-4xl tracking-tight leading-none mb-2">
            Welcome back
          </h2>
          <p className="text-zinc-500 text-sm mb-8">
            Sign in to continue managing the platform. Use <span className="text-white">admin@ott.com / Admin@123</span> to explore.
          </p>

          <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2">Work Email</label>
          <input
            data-testid={AUTH.loginEmail}
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#141414] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none transition-colors"
            placeholder="you@studio.com"
          />

          <div className="flex items-center justify-between mt-6 mb-2">
            <label className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Password</label>
            <Link data-testid={AUTH.forgotLink} to="/forgot-password" className="text-[10px] uppercase tracking-[0.2em] text-[#E50914] hover:text-[#F40612]">
              Forgot?
            </Link>
          </div>
          <div className="relative">
            <input
              data-testid={AUTH.loginPassword}
              type={show ? "text" : "password"}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#141414] border border-[#27272A] rounded-sm px-4 py-3 pr-11 text-white focus:border-[#E50914] focus:outline-none transition-colors"
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShow((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
            >
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          <label className="mt-6 flex items-center gap-2 cursor-pointer text-sm text-zinc-400">
            <input
              data-testid={AUTH.loginRemember}
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="accent-[#E50914]"
            />
            Keep me signed in for 12 hours
          </label>

          <button
            data-testid={AUTH.loginSubmit}
            disabled={loading}
            type="submit"
            className="mt-8 w-full h-12 bg-[#E50914] hover:bg-[#F40612] disabled:opacity-60 text-white font-semibold uppercase tracking-[0.2em] text-sm rounded-sm transition-colors flex items-center justify-center gap-2"
          >
            {loading ? "Signing in…" : "Sign In"} <ArrowRight className="w-4 h-4" />
          </button>

          <div className="mt-8 border-t border-[#27272A] pt-6 text-[10px] uppercase tracking-widest text-zinc-600">
            Protected by JWT · RSA-OAEP · AES-256 · HMAC-SHA256
          </div>
        </motion.form>
      </div>
    </div>
  );
}

import React, { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Zap } from "lucide-react";
import { toast } from "sonner";
import { authService } from "../../services";
import { AUTH } from "../../constants/testIds";

export default function ResetPassword() {
  const [params] = useSearchParams();
  const email = params.get("email") || "";
  const otp = params.get("otp") || "";
  const nav = useNavigate();
  const [pwd, setPwd] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (pwd !== confirm) return toast.error("Passwords do not match");
    if (pwd.length < 6) return toast.error("Password must be at least 6 characters");
    setLoading(true);
    try {
      await authService.resetPassword(email, otp, pwd);
      toast.success("Password reset. Please sign in.");
      nav("/login");
    } catch (err) {
      toast.error("Reset failed", { description: err?.detail });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white flex items-center justify-center p-6">
      <motion.form initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} onSubmit={submit} className="w-full max-w-md">
        <div className="flex items-center gap-2.5 mb-10">
          <div className="w-10 h-10 flex items-center justify-center bg-[#E50914] rounded-sm">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div className="font-display text-xl uppercase tracking-[0.25em]">CineStream</div>
        </div>
        <div className="text-[10px] uppercase tracking-[0.25em] text-[#E50914] font-semibold mb-3">— New Password</div>
        <h2 className="font-display uppercase text-4xl tracking-tight leading-none mb-2">Create a new password</h2>
        <p className="text-zinc-500 text-sm mb-8">Choose a strong password you haven&apos;t used before.</p>

        <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2">New Password</label>
        <input
          data-testid={AUTH.resetPassword}
          type="password"
          required
          value={pwd}
          onChange={(e) => setPwd(e.target.value)}
          className="w-full bg-[#141414] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none"
        />
        <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2 mt-6">Confirm Password</label>
        <input
          data-testid={AUTH.resetConfirm}
          type="password"
          required
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          className="w-full bg-[#141414] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none"
        />
        <button
          data-testid={AUTH.resetSubmit}
          disabled={loading}
          type="submit"
          className="mt-8 w-full h-12 bg-[#E50914] hover:bg-[#F40612] disabled:opacity-60 text-white font-semibold uppercase tracking-[0.2em] text-sm rounded-sm flex items-center justify-center gap-2"
        >
          {loading ? "Saving…" : "Reset Password"} <ArrowRight className="w-4 h-4" />
        </button>
      </motion.form>
    </div>
  );
}

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Zap } from "lucide-react";
import { toast } from "sonner";
import { authService } from "../../services";
import { AUTH } from "../../constants/testIds";

export default function ForgotPassword() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authService.forgotPassword(email);
      toast.success("OTP sent", { description: res.demo_otp ? `Demo OTP: ${res.demo_otp}` : "Check your email inbox" });
      nav(`/verify-otp?email=${encodeURIComponent(email)}${res.demo_otp ? `&hint=${res.demo_otp}` : ""}`);
    } catch (err) {
      toast.error("Could not send OTP", { description: err?.detail || "Try again" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white flex items-center justify-center p-6">
      <motion.form
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={submit}
        className="w-full max-w-md"
      >
        <div className="flex items-center gap-2.5 mb-10">
          <div className="w-10 h-10 flex items-center justify-center bg-[#E50914] rounded-sm">
            <Zap className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <div className="font-display text-xl uppercase tracking-[0.25em]">CineStream</div>
        </div>
        <div className="text-[10px] uppercase tracking-[0.25em] text-[#E50914] font-semibold mb-3">— Reset Password</div>
        <h2 className="font-display uppercase text-4xl tracking-tight leading-none mb-2">Forgot your password?</h2>
        <p className="text-zinc-500 text-sm mb-8">Enter the email you use to sign in. We&apos;ll send a one-time code.</p>
        <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-2">Work Email</label>
        <input
          data-testid={AUTH.forgotEmail}
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-[#141414] border border-[#27272A] rounded-sm px-4 py-3 text-white focus:border-[#E50914] focus:outline-none transition-colors"
          placeholder="you@studio.com"
        />
        <button
          data-testid={AUTH.forgotSubmit}
          disabled={loading}
          type="submit"
          className="mt-6 w-full h-12 bg-[#E50914] hover:bg-[#F40612] disabled:opacity-60 text-white font-semibold uppercase tracking-[0.2em] text-sm rounded-sm flex items-center justify-center gap-2"
        >
          {loading ? "Sending…" : "Send OTP"} <ArrowRight className="w-4 h-4" />
        </button>
        <Link to="/login" className="mt-6 inline-flex items-center gap-2 text-xs text-zinc-500 hover:text-white uppercase tracking-[0.2em]">
          <ArrowLeft className="w-3 h-3" /> Back to sign in
        </Link>
      </motion.form>
    </div>
  );
}

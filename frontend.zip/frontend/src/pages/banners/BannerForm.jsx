import React, {
    useEffect,
    useState
} from "react";
import {
    useNavigate,
    useParams
} from "react-router-dom";
import {
    useQuery,
    useMutation,
    useQueryClient
} from "@tanstack/react-query";
import {
    toast
} from "sonner";

import {
    Save,
    ArrowLeft,
    Trash2
} from "lucide-react";

import PageHeader from "../../components/common/PageHeader";
import {
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger
} from "../../components/ui/tabs";

import {
    bannerService,
    contentService
} from "../../services";

function Field({
    label,
    children
}) {

    return (

        <div>

<label className="
block
text-[10px]
uppercase
tracking-[0.2em]
text-zinc-500
mb-1.5
font-medium
">

{label}

</label>

{children}

</div>

    )

}

const inputCls = `
w-full
bg-[#0A0A0A]
border
border-[#27272A]
rounded-sm
px-3
py-2
text-sm
text-white
focus:border-[#E50914]
focus:outline-none
`;



export default function BannerForm() {

    const {
        id
    } = useParams();

console.log("id =", id);
    const nav = useNavigate();

    const qc = useQueryClient();

   const isNew = location.pathname === "/content/banners/new";

console.log("isNew =", isNew);

 const [form, setForm] = useState({
  title: "",
  description: "",
  bannerType: "HOME",

  desktop_image: "",
  mobile_image: "",
  background_video: "",

  genre: "",
  release_year: "",
  content_rating: "",
  duration_minutes: "",
  category: "",

  language: "English",

  platform: ["ALL"],

  content_id: null,
  clickAction: "CONTENT",
  redirect_url: "",
  placement: "CAROUSEL",

  cta_text: "Watch Now",

  start_date: "",
  end_date: "",

  display_order: 1,

  priority: 1,
  status: "PUBLISHED",

  user_segment: "ALL",
  country: "ALL",

  auto_play: true,
  duration: 5,
  drm: false,
});
const [files, setFiles] = useState({
    desktopImage: null,
    mobileImage: null,
    tvImage: null,
    backgroundVideo: null,
});

    const setF = (key, value) => {

        setForm(f => ({
            ...f,
            [key]: value
        }));

    };
const handleFileSelect = (e, field) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const preview = URL.createObjectURL(file);

    switch(field){

        case "desktop_image":
            setFiles(f=>({...f, desktopImage:file}));
            break;

        case "mobile_image":
            setFiles(f=>({...f, mobileImage:file}));
            break;

        case "background_video":
            setFiles(f=>({...f, backgroundVideo:file}));
            break;

        case "tv_image":
            setFiles(f=>({...f, tvImage:file}));
            break;
    }

    setF(field,preview);
};
    const {
  data: existing,
  isLoading,
  error
} = useQuery({
  queryKey: ["banner", id],
  queryFn: async () => {
    console.log("Calling getBannerById...");
    const res = await bannerService.getBannerById(id);
    console.log("Response:", res);
    return res.data;
  },
  enabled: !!id,
});

    const {
        data: contents = []
    } = useQuery({

        queryKey: [
            "banner-content"
        ],

        queryFn: () => contentService.list({
            page_size: 100
        })

    });

useEffect(() => {
    if (!existing) return;

    const b = existing;

    setForm({
        title: b.title ?? "",
        description: b.description ?? "",
        bannerType: b.bannerType ?? "HOME",

        desktop_image: b.desktopImageUrl ?? "",
        mobile_image: b.mobileImageUrl ?? "",
        background_video: b.backgroundVideoUrl ?? "",

        genre: b.genre ?? "",
        release_year: b.releaseYear ?? "",

        content_rating: b.contentRating ?? "",
        duration_minutes: b.durationMinutes ?? "",

        category: b.category ?? "",
        language: b.language ?? "",

        platform: b.platforms ?? ["ALL"],

        content_id: b.contentId,

        clickAction: b.clickAction ?? "CONTENT",

        redirect_url: b.redirectUrl ?? "",

        placement: b.placement ?? "CAROUSEL",

        cta_text: b.ctaText ?? "",

        start_date: b.startDateTime?.substring(0,16) ?? "",
        end_date: b.endDateTime?.substring(0,16) ?? "",

        display_order: b.displayOrder ?? 1,
        priority: b.priority ?? 1,

        status: b.status ?? "PUBLISHED",

        user_segment: b.userSegment ?? "ALL",

        country: b.country ?? "ALL",

        auto_play: b.autoPlay ?? true,

        duration: b.autoPlayDuration ?? 5,

        drm: b.drmProtected ?? false
    });

}, [existing]);
console.log("existing =", existing);
 const saveMutation = useMutation({
   mutationFn: ({files, metadata}) =>
    isNew
        ? bannerService.createBanner(files, metadata)
        : bannerService.updateBanner(id,files, metadata),

    onSuccess() {
        toast.success("Banner Saved");
    },

    onError(error) {
        console.error(error);
        toast.error(error?.response?.data?.message || "Save failed");
    },
});
    const deleteMutation = useMutation({

        mutationFn: () => bannerService.deleteBanner(id),

        onSuccess() {

            toast.success("Deleted");

            nav("/banners");

        }

    });

    const submit = (e) => {
    e.preventDefault();

    console.log(files);
    console.log(form);
const metadata = {
    title: form.title,
    description: form.description,

    bannerType: form.bannerType,

    category: form.category,

    genres: form.genre,

    language: form.language,

    releaseYear: Number(form.release_year),

    contentRating: form.content_rating,

    durationMinutes: Number(form.duration_minutes),

    clickAction: form.clickAction,

    contentId: form.content_id,

    redirectUrl: form.redirect_url,

    ctaText: form.cta_text,

    platforms: form.platform,

    userSegment: form.user_segment,

    country: form.country,

    placement: form.placement,

    displayOrder: Number(form.display_order),

    priority: Number(form.priority),

    autoPlay: form.auto_play,

    autoPlayDuration: Number(form.duration),

    drmProtected: form.drm,

    startDateTime: form.start_date,

    endDateTime: form.end_date,

    status: form.status,

    active: true
};
    saveMutation.mutate({
        files,
        metadata: metadata,
    });
};

    return (

        <form
onSubmit={submit}
className="space-y-6"
>



<PageHeader

title={
isNew
?
"New Banner"
:
form.title
}

subtitle="
Manage OTT hero banners and campaigns
"


actions={

<>


<button

type="button"

onClick={()=>nav(-1)}

className="
h-9
px-3
border
border-[#27272A]
text-white
rounded-sm
text-xs
uppercase
flex
items-center
gap-2
"

>

<ArrowLeft size={14}/>

Back

</button>




{
!isNew &&

<button

type="button"

onClick={()=>deleteMutation.mutate()}

className="
h-9
px-3
border
border-red-600
text-red-400
rounded-sm
text-xs
uppercase
flex
items-center
gap-2
"

>

<Trash2 size={14}/>

Delete

</button>

}




<button

type="submit"

className="
h-9
px-3
bg-[#E50914]
text-white
rounded-sm
text-xs
uppercase
flex
items-center
gap-2
"

>

<Save size={14}/>

Save

</button>



</>


}


/>





<Tabs defaultValue="overview">


<TabsList className="
bg-transparent
border-b
border-[#27272A]
w-full
rounded-none
">


{
[
"overview",
"media",
"targeting",
"scheduling",
"action",
"advanced"

].map(t=>(


<TabsTrigger

key={t}

value={t}

className="
uppercase
text-xs
tracking-widest
text-zinc-500
data-[state=active]:text-white
"

>

{t}

</TabsTrigger>


))

}



</TabsList>






{/* Overview */}

<TabsContent value="overview" className="mt-6">


<div className="
grid
grid-cols-1
lg:grid-cols-2
gap-6
">


<Field label="Banner Title">

<input

value={form.title}

onChange={e=>setF(
"title",
e.target.value
)}

className={inputCls}

/>

</Field>



<Field label="Banner Type">


<select

value={form.bannerType}

onChange={e=>setF("bannerType",e.target.value)}

className={inputCls}

>

<option value="HOME">
Hero Banner
</option>


<option value="PROMO">
Promotion
</option>


<option value="ADVERTISEMENT">
Advertisement
</option>


</select>


</Field>




<Field label="Description">


<textarea

rows={4}

value={form.description}

onChange={
e=>setF(
"description",
e.target.value
)
}

className={inputCls}

/>


</Field>



<Field label="Language">

<input

value={form.language}

onChange={
e=>setF(
"language",
e.target.value
)
}

className={inputCls}

/>


</Field>
<Field label="Genres">

<input
    value={form.genre || ""}
    onChange={(e)=>setF("genre",e.target.value)}
    placeholder="Action, Thriller, Comedy"
    className={inputCls}
/>

</Field>
<Field label="Release Year">

<input
    type="number"
    value={form.release_year || ""}
    onChange={(e)=>setF("release_year",e.target.value)}
    className={inputCls}
/>

</Field>
<Field label="Content Rating">

<select
    value={form.content_rating || ""}
    onChange={(e)=>setF("content_rating",e.target.value)}
    className={inputCls}
>

<option value="">Select</option>
<option value="U">U</option>
<option value="U/A 7+">U/A 7+</option>
<option value="U/A 13+">U/A 13+</option>
<option value="U/A 16+">U/A 16+</option>
<option value="A">A</option>

</select>

</Field>

<Field label="Duration (Minutes)">

<input
    type="number"
    value={form.duration_minutes || ""}
    onChange={(e)=>setF("duration_minutes",e.target.value)}
    className={inputCls}
/>

</Field>

<Field label="Category">

<select
    value={form.category || ""}
    onChange={(e)=>setF("category",e.target.value)}
    className={inputCls}
>

<option value="">Select Category</option>
<option value="MOVIE">Movie</option>
<option value="WEB_SERIES">Web Series</option>
<option value="LIVE_TV">Live TV</option>
<option value="SPORTS">Sports</option>
<option value="KIDS">Kids</option>

</select>

</Field>


</div>


</TabsContent>








{/* Media */}


<TabsContent value="media" className="mt-6">


<div className="
grid
grid-cols-1
md:grid-cols-2
gap-6
">


<Field label="Desktop Banner (1920x800)">
  <input
    type="file"
    accept="image/*"
    onChange={(e) => handleFileSelect(e, "desktop_image")}
    className={inputCls}
  />

  {form.desktop_image && (
    <img
      src={form.desktop_image}
      className="mt-3 rounded w-full max-w-lg"
    />
  )}
</Field>



<Field label="Mobile Banner (1080x1440)">
  <input
    type="file"
    accept="image/*"
    onChange={(e) => handleFileSelect(e, "mobile_image")}
    className={inputCls}
  />

  {form.mobile_image && (
    <img
      src={form.mobile_image}
      className="mt-3 rounded w-full max-w-sm"
    />
  )}
</Field>


<Field label="Background Video">

<input
    type="file"
    accept="video/*"
    onChange={(e)=>handleFileSelect(e,"background_video")}
    className={inputCls}
/>

{form.background_video && (
    <video
        controls
        className="mt-3 rounded w-full max-w-xl"
    >
        <source src={form.background_video}/>
    </video>
)}

</Field>



</div>



{
form.desktop_image &&

<img

src={form.desktop_image}

className="
mt-6
max-w-xl
rounded
"

/>

}


</TabsContent>








{/* Targeting */}

<TabsContent value="targeting" className="mt-6">


<div className="
grid
grid-cols-2
gap-6
">


<Field label="Platform">

<select

className={inputCls}

value={form.platform[0]}

onChange={
e=>setF(
"platform",
[e.target.value]
)
}

>

<option value="ALL">ALL</option>
<option value="WEB">WEB</option>
<option value="MOBILE">MOBILE</option>
<option value="TV">TV</option>

</select>


</Field>



<Field label="User Segment">


<select

className={inputCls}

value={form.user_segment}

onChange={
e=>setF(
"user_segment",
e.target.value
)
}

>

<option>ALL</option>

<option>FREE</option>

<option>PREMIUM</option>


</select>


</Field>



</div>


</TabsContent>









{/* Scheduling */}


<TabsContent value="scheduling" className="mt-6">


<div className="
grid
grid-cols-2
gap-6
">


<Field label="Start Date">

<input

type="datetime-local"

className={inputCls}

value={form.start_date}

onChange={
e=>setF(
"start_date",
e.target.value
)
}

/>

</Field>



<Field label="End Date">

<input

type="datetime-local"

className={inputCls}

value={form.end_date}

onChange={
e=>setF(
"end_date",
e.target.value
)
}

/>

</Field>



<Field label="Display Order">

<input

type="number"

value={form.display_order}

onChange={
e=>setF(
"display_order",
Number(e.target.value)
)
}

className={inputCls}

/>

</Field>



</div>


</TabsContent>









{/* Action */}


<TabsContent value="action" className="mt-6">


<div className="
grid
grid-cols-2
gap-6
">


<Field label="Redirect Type">

<select
    className={inputCls}
    value={form.clickAction}
    onChange={(e)=>setF("clickAction",e.target.value)}
>

<option value="CONTENT">Content</option>
<option value="URL">URL</option>
<option value="SUBSCRIPTION">Subscription</option>
<option value="NONE">None</option>

</select>

</Field>



{form.clickAction === "CONTENT" && (

<Field label="Content">

<select
    className={inputCls}
    value={form.content_id || ""}
    onChange={(e)=>setF("content_id",e.target.value)}
>

<option value="">Select Content</option>

{contents.items?.map(c=>(
<option key={c.id} value={c.id}>
{c.title}
</option>
))}

</select>

</Field>

)}

{form.clickAction === "URL" && (

<Field label="Redirect URL">

<input
    value={form.redirect_url || ""}
    onChange={(e)=>setF("redirect_url",e.target.value)}
    placeholder="https://example.com"
    className={inputCls}
/>

</Field>

)}

{form.clickAction === "SUBSCRIPTION" && (

<div className="rounded border border-[#27272A] p-4 text-sm text-zinc-400">
Banner will redirect users to the Subscription Plans page.
</div>

)}

{form.clickAction === "NONE" && (

<div className="rounded border border-[#27272A] p-4 text-sm text-zinc-400">
No action will be performed when the banner is clicked.
</div>

)}



<Field label="CTA Text">


<input

value={form.cta_text}

onChange={
e=>setF(
"cta_text",
e.target.value
)
}

className={inputCls}

/>


</Field>



</div>


</TabsContent>








{/* Advanced */}


<TabsContent value="advanced" className="mt-6">


<label className="
flex
items-center
gap-3
border
border-[#27272A]
p-4
">


<input

type="checkbox"

checked={form.auto_play}

onChange={
e=>setF(
"auto_play",
e.target.checked
)
}

/>


<span>
Auto Play Carousel
</span>


</label>


</TabsContent>





</Tabs>


</form>

    )

}
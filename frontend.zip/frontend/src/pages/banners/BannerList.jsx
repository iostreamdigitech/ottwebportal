import React, {useState} from "react";
import {
 Plus,
 Search,
 Edit3,
 Trash2,
 Eye,
 Image as ImageIcon
} from "lucide-react";

import {motion} from "framer-motion";
import {useNavigate} from "react-router-dom";
import {useQuery,useMutation,useQueryClient} from "@tanstack/react-query";
import {toast} from "sonner";

import PageHeader from "../../components/common/PageHeader";
import StatusBadge from "../../components/common/StatusBadge";
import EmptyState from "../../components/common/EmptyState";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import {bannerService} from "../../services";


const STATUS=[
 "all",
 "draft",
 "active",
 "inactive",
 "expired"
];


export default function BannerList(){

const nav=useNavigate();
const qc=useQueryClient();


const [search,setSearch]=useState("");
const [status,setStatus]=useState("all");
const [deleteBanner,setDeleteBanner]=useState(null);



const { data, isLoading } = useQuery({
  queryKey: ["banners"],
  queryFn: () => bannerService.getAllBanners()
});


const deleteMutation=useMutation({

 mutationFn:(id)=>
    bannerService.deleteBanner(id),

 onSuccess(){

 toast.success("Banner deleted");

 qc.invalidateQueries({
  queryKey:["banners"]
 });

 setDeleteBanner(null);

 }

});


const banners=data?.data || [];



return (

<div className="space-y-6">


<PageHeader

title="Banner Maintenance"

subtitle="Manage OTT homepage banners and promotional campaigns"

actions={

<button

onClick={()=>
 nav("/content/banners/new")
}

className="
h-9 px-3
bg-[#E50914]
rounded-sm
text-xs
uppercase
tracking-widest
text-white
flex items-center gap-2
"

>

<Plus size={14}/>

Add Banner

</button>


}

/>



{/* Search */}


<div className="flex gap-3">


<div className="
relative
max-w-md
flex-1
">


<Search

className="
absolute
left-3
top-1/2
-translate-y-1/2
text-zinc-500
"

/>


<input

placeholder="Search banners..."

value={search}

onChange={
e=>setSearch(e.target.value)
}

className="
w-full
bg-[#141414]
border
border-[#27272A]
rounded-sm
pl-10
py-2.5
text-white
"

/>


</div>



<select

value={status}

onChange={
e=>setStatus(e.target.value)
}

className="
bg-[#141414]
border
border-[#27272A]
text-white
px-4
rounded-sm
"

>


{
STATUS.map(s=>

<option key={s}>
{s}
</option>

)
}


</select>


</div>




{
isLoading ?

<div>
Loading...
</div>


:

banners.length===0 ?

<EmptyState

title="No banners found"

subtitle="Create your first OTT banner"

/>


:

<div className="
grid
grid-cols-2
md:grid-cols-3
lg:grid-cols-4
xl:grid-cols-5
gap-4
">


{

banners.map((banner,index)=>(


<motion.div

key={banner.id}

initial={{
opacity:0,
y:10
}}

animate={{
opacity:1,
y:0
}}

className="
group
bg-[#141414]
border
border-[#27272A]
rounded-sm
overflow-hidden
"


>


<div className="
aspect-video
relative
bg-black
">


{banner.desktopImageUrl ? (
    <img
        src={banner.desktopImageUrl}
        alt={banner.title}
        className="w-full h-full object-cover"
    />
) : (
    <div className="flex items-center justify-center h-full text-zinc-700">
        <ImageIcon size={50} />
    </div>
)}


<div className="
absolute
top-2
left-2
">

<StatusBadge
status={banner.status}
/>


</div>




<div className="
absolute
bottom-0
left-0
right-0
p-3
bg-gradient-to-t
from-black
">


<h3 className="
text-white
font-semibold
">

{banner.title}

</h3>


<p className="
text-xs
text-zinc-400
">

{banner.platforms?.join(", ")}

{" | "}

Order {banner.displayOrder}

</p>


</div>



<div className="
absolute
inset-0
bg-black/60
opacity-0
group-hover:opacity-100
flex
items-center
justify-center
gap-2
">


<button

onClick={()=>
nav(`/content/banners/${banner.id}`)
}

className="
bg-red-600
p-2
rounded
"

>

<Edit3 size={16}/>

</button>


<button

className="
bg-zinc-800
p-2
rounded
"

>

<Eye size={16}/>

</button>



<button

onClick={()=>
setDeleteBanner(banner)
}

className="
bg-zinc-800
p-2
rounded
"

>

<Trash2 size={16}/>

</button>


</div>



</div>


</motion.div>


))


}


</div>


}




<ConfirmDialog

open={!!deleteBanner}

onOpenChange={()=>
setDeleteBanner(null)
}

title={`Delete ${deleteBanner?.title}?`}

description="Banner will be removed from OTT applications."

onConfirm={()=>
deleteMutation.mutate(deleteBanner.id)
}

/>



</div>


)

}
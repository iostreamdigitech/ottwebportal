import React, { useState } from "react";
import {
  useQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, Edit3 } from "lucide-react";

import PageHeader from "../../components/common/PageHeader";
import StatusBadge from "../../components/common/StatusBadge";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import EmptyState from "../../components/common/EmptyState";
import { TableSkeleton } from "../../components/common/LoadingSkeleton";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";

import {
  categoryService,
  genreService,
  languageService,
  castService,
  crewService,
} from "../../services";

const SERVICE_MAP = {
  categories: {
    svc: categoryService,
    title: "Categories",
    subtitle: "Content categories displayed on the storefront.",
    fields: {
      name: "categoryName",
      code: "categoryCode",
      description: "description",
      status: "active",
      order: "displayOrder",
    },
  },

  genres: {
    svc: genreService,
    title: "Genres",
    subtitle: "Genre taxonomy attached to each title.",
    fields: {
      name: "genreName",
      code: "genreCode",
      description: null,
      status: "active",
      order: "displayOrder",
    },
  },

  languages: {
    svc: languageService,
    title: "Languages",
    subtitle: "Supported audio/subtitle languages.",
    fields: {
      name: "languageName",
      code: "isoCode",
      description: "nativeName",
      status: "active",
      order: null,
    },
  },

  cast: {
    svc: castService,
    title: "Cast",
    subtitle: "Actors available for tagging.",
    fields: {
      name: "name",
      code: "role",
      description: "bio",
      status: "active",
      order: null,
    },
  },

  crew: {
    svc: crewService,
    title: "Crew",
    subtitle: "Directors, Producers and Technicians.",
    fields: {
      name: "name",
      code: "code",
      description: "description",
      status: "active",
      order: null,
    },
  },
};

const inputCls =
  "w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none";

/**
 * Normalize API response
 * Converts Category / Genre / Language / Cast / Crew
 * into a common object.
 */
const normalizeItem = (item, meta) => ({
  ...item,

  name: item?.[meta.fields.name] ?? "",

  code: item?.[meta.fields.code] ?? "",

  description: meta.fields.description
    ? item?.[meta.fields.description] ?? ""
    : "",

  status:
    typeof item?.[meta.fields.status] === "boolean"
      ? item[meta.fields.status]
        ? "Active"
        : "Inactive"
      : item?.[meta.fields.status] ?? "Inactive",

  order: meta.fields.order
    ? item?.[meta.fields.order]
    : null,
});

/**
 * Convert generic form values
 * into API-specific payload.
 */
const buildPayload = (resource, fd) => {
  const active = fd.get("status") === "active";

  switch (resource) {
    case "categories":
      return {
        categoryName: fd.get("name"),
        categoryCode: fd.get("code"),
        description: fd.get("description"),
        active,
      };

    case "genres":
      return {
        genreName: fd.get("name"),
        genreCode: fd.get("code"),
        active,
      };

    case "languages":
      return {
        languageName: fd.get("name"),
        isoCode: fd.get("code"),
        nativeName: fd.get("description"),
        active,
      };

    case "cast":
    case "crew":
    default:
      return {
        name: fd.get("name"),
        code: fd.get("code"),
        description: fd.get("description"),
        active,
      };
  }
};
export default function MasterList({ resource }) {
  const meta = SERVICE_MAP[resource];
  const queryClient = useQueryClient();

  const [form, setForm] = useState(null);
  const [del, setDel] = useState(null);

  /*
   * Fetch List
   */
  const {
    data: response,
    isLoading,
    isFetching,
  } = useQuery({
    queryKey: [resource],
    queryFn: () => meta.svc.list(),
  });

  /*
   * APIs may return:
   *
   * response.data
   * response.data.data
   * response.items
   * response
   *
   * Handle all formats.
   */
  const data = Array.isArray(response)
    ? response
    : response?.data
    ? Array.isArray(response.data)
      ? response.data
      : response.data.data || []
    : response?.items || [];

  /*
   * Save
   */
  const saveMutation = useMutation({
    mutationFn: (payload) => {
      if (form?.id) {
        return meta.svc.update(form.id, payload);
      }

      return meta.svc.create(payload);
    },

    onSuccess: () => {
      toast.success(
        `${meta.title.slice(0, -1)} saved successfully`
      );

      queryClient.invalidateQueries({
        queryKey: [resource],
      });

      setForm(null);
    },

    onError: (error) => {
      toast.error(
        error?.response?.data?.message ||
          error?.message ||
          "Unable to save record."
      );
    },
  });

  /*
   * Delete
   */
  const deleteMutation = useMutation({
    mutationFn: (id) => meta.svc.delete(id),

    onSuccess: () => {
      toast.success(
        `${meta.title.slice(0, -1)} deleted successfully`
      );

      queryClient.invalidateQueries({
        queryKey: [resource],
      });

      setDel(null);
    },

    onError: (error) => {
      toast.error(
        error?.response?.data?.message ||
          error?.message ||
          "Unable to delete record."
      );
    },
  });

  /*
   * Edit Click
   */
  const handleEdit = (row) => {
    setForm(normalizeItem(row, meta));
  };

  /*
   * Add Click
   */
  const handleAdd = () => {
    setForm({
      id: null,
      name: "",
      code: "",
      description: "",
      status: "Active",
    });
  };

  /*
   * Save Form
   */
  const handleSubmit = (e) => {
    e.preventDefault();

    const fd = new FormData(e.currentTarget);

    saveMutation.mutate(
      buildPayload(resource, fd)
    );
  };

  /*
   * Delete Confirm
   */
  const handleDelete = () => {
    if (!del) return;

    deleteMutation.mutate(del.id);
  };

  return (
    <div className="space-y-6">
     <PageHeader
  title={meta.title}
  subtitle={meta.subtitle}
  actions={
    <button
      data-testid={`${resource}-add-button`}
      onClick={handleAdd}
      className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2"
    >
      <Plus className="w-3.5 h-3.5" />
      Add {meta.title.slice(0, -1)}
    </button>
  }
/>
              {isLoading || isFetching ? (
        <TableSkeleton />
      ) : data.length === 0 ? (
        <EmptyState
          title={`No ${meta.title.toLowerCase()} found`}
          description={`Click "Add ${meta.title.slice(
            0,
            -1
          )}" to create your first record.`}
        />
      ) : (
        <div className="border border-[#27272A] rounded-sm overflow-hidden bg-[#141414]">
          <table className="w-full text-sm">
            <thead className="bg-[#0A0A0A] text-[10px] uppercase tracking-[0.2em] text-zinc-500">
              <tr>
                <th className="p-3 text-left">Name</th>
                <th className="p-3 text-left">Code</th>
                <th className="p-3 text-left">Description</th>
                <th className="p-3 text-center">Status</th>

                {meta.fields.order && (
                  <th className="p-3 text-center">
                    Display Order
                  </th>
                )}

                <th className="p-3 text-right">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              {data.map((row) => {
                const item = normalizeItem(row, meta);

                return (
                  <tr
                    key={item.id}
                    className="border-t border-[#27272A] hover:bg-[#1E1E1E]"
                  >
                    <td className="p-3 font-medium text-white">
                      {item.name || "-"}
                    </td>

                    <td className="p-3 text-zinc-400 font-mono">
                      {item.code || "-"}
                    </td>

                    <td className="p-3 text-zinc-400">
                      {item.description || "—"}
                    </td>

                    <td className="p-3 text-center">
                      <StatusBadge
                        status={item.status}
                      />
                    </td>

                    {meta.fields.order && (
                      <td className="p-3 text-center text-zinc-400">
                        {item.order ?? "-"}
                      </td>
                    )}

                    <td className="p-3">
                      <div className="flex justify-end gap-2">
                        <button
                          data-testid={`${resource}-edit-${item.id}`}
                          onClick={() =>
                            handleEdit(row)
                          }
                          className="w-8 h-8 rounded-sm border border-[#27272A] hover:border-[#E50914] text-zinc-400 hover:text-[#E50914] flex items-center justify-center transition"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          data-testid={`${resource}-delete-${item.id}`}
                          onClick={() =>
                            setDel(item)
                          }
                          className="w-8 h-8 rounded-sm border border-[#27272A] hover:border-red-600 text-zinc-400 hover:text-red-500 flex items-center justify-center transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
            <Dialog
        open={!!form}
        onOpenChange={(open) => {
          if (!open) {
            setForm(null);
          }
        }}
      >
        <DialogContent className="bg-[#141414] border border-[#27272A] text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="uppercase tracking-widest text-sm">
              {form?.id
                ? `Edit ${meta.title.slice(0, -1)}`
                : `Add ${meta.title.slice(0, -1)}`}
            </DialogTitle>
          </DialogHeader>

          <form
            onSubmit={handleSubmit}
            className="space-y-4"
          >
            {/* Name */}
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1">
                Name
              </label>

              <input
                name="name"
                required
                className={inputCls}
                defaultValue={form?.name || ""}
              />
            </div>

            {/* Code */}
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1">
                Code
              </label>

              <input
                name="code"
                className={inputCls}
                defaultValue={form?.code || ""}
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1">
                Description
              </label>

              <textarea
                rows={3}
                name="description"
                className={`${inputCls} resize-none`}
                defaultValue={form?.description || ""}
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1">
                Status
              </label>

              <select
                name="status"
                className={inputCls}
                defaultValue={
                  form?.status === "Inactive"
                    ? "inactive"
                    : "active"
                }
              >
                <option value="active">
                  Active
                </option>

                <option value="inactive">
                  Inactive
                </option>
              </select>
            </div>

            <DialogFooter className="pt-2">
              <button
                type="button"
                onClick={() => setForm(null)}
                className="h-9 px-4 border border-[#27272A] rounded-sm text-xs uppercase tracking-widest hover:border-zinc-500"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={saveMutation.isPending}
                className="h-9 px-4 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest disabled:opacity-60"
              >
                {saveMutation.isPending
                  ? "Saving..."
                  : "Save"}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!del}
        onOpenChange={(open) => {
          if (!open) {
            setDel(null);
          }
        }}
        title={`Delete "${del?.name || ""}"?`}
        description="This action cannot be undone."
        confirmText="Delete"
        onConfirm={handleDelete}
        loading={deleteMutation.isPending}
      />
    </div>
  );
}
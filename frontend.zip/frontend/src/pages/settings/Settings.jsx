import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Save } from "lucide-react";
import PageHeader from "../../components/common/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { settingsService } from "../../services";

const inputCls = "w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none";

function Section({ title, subtitle, children, onSave, saving }) {
  return (
    <div className="bg-[#141414] border border-[#27272A] rounded-sm p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="font-display uppercase text-lg text-white tracking-widest">{title}</div>
          {subtitle && <p className="text-xs text-zinc-500 mt-1 max-w-xl">{subtitle}</p>}
        </div>
        <button data-testid={`settings-save-${title.toLowerCase().replace(/\s+/g, "-")}`} onClick={onSave} disabled={saving} className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2 disabled:opacity-50">
          <Save className="w-3.5 h-3.5" /> Save
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {children}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-1.5 font-medium">{label}</label>
      {children}
    </div>
  );
}

export default function Settings() {
  const qc = useQueryClient();
  const { data: settings = {} } = useQuery({ queryKey: ["settings"], queryFn: () => settingsService.get() });
  const [general, setGeneral] = useState({});
  const [smtp, setSmtp] = useState({});
  const [payment, setPayment] = useState({});
  const [security, setSecurity] = useState({});
  const [cdn, setCdn] = useState({});

  useEffect(() => {
    setGeneral(settings.general || { site_name: "CineStream OTT", support_email: "support@cinestream.tv", timezone: "Asia/Kolkata", language: "en" });
    setSmtp(settings.smtp || { host: "smtp.sendgrid.net", port: 587, username: "", from_email: "no-reply@cinestream.tv" });
    setPayment(settings.payment || { stripe_publishable_key: "", razorpay_key_id: "", currency: "INR" });
    setSecurity(settings.security || { session_timeout: 60, password_min_length: 8, mfa_enabled: true, rate_limit: 100 });
    setCdn(settings.cdn || { provider: "AWS CloudFront", origin_url: "", edge_regions: "Global" });
  }, [settings]);

  const mut = useMutation({
    mutationFn: ({ section, values }) => settingsService.update(section, values),
    onSuccess: () => { toast.success("Settings saved"); qc.invalidateQueries({ queryKey: ["settings"] }); },
    onError: (e) => toast.error("Save failed", { description: e?.detail }),
  });

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" subtitle="Global configuration for branding, delivery, billing and security." />

      <Tabs defaultValue="general">
        <TabsList className="bg-transparent border-b border-[#27272A] w-full justify-start rounded-none h-auto p-0 gap-1">
          {["general", "smtp", "payment", "security", "cdn", "drm"].map((t) => (
            <TabsTrigger key={t} value={t} data-testid={`settings-tab-${t}`} className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#E50914] data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-500 uppercase tracking-[0.2em] text-xs px-4 py-3">
              {t}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="general" className="mt-6">
          <Section title="General" subtitle="Public storefront identity." saving={mut.isPending} onSave={() => mut.mutate({ section: "general", values: general })}>
            <Field label="Site Name"><input value={general.site_name || ""} onChange={(e) => setGeneral({ ...general, site_name: e.target.value })} className={inputCls} /></Field>
            <Field label="Support Email"><input type="email" value={general.support_email || ""} onChange={(e) => setGeneral({ ...general, support_email: e.target.value })} className={inputCls} /></Field>
            <Field label="Timezone"><input value={general.timezone || ""} onChange={(e) => setGeneral({ ...general, timezone: e.target.value })} className={inputCls} /></Field>
            <Field label="Default Language">
              <select value={general.language || "en"} onChange={(e) => setGeneral({ ...general, language: e.target.value })} className={inputCls}>
                <option value="en">English</option><option value="hi">Hindi</option><option value="ta">Tamil</option><option value="ar">Arabic</option><option value="fr">French</option><option value="es">Spanish</option>
              </select>
            </Field>
          </Section>
        </TabsContent>

        <TabsContent value="smtp" className="mt-6">
          <Section title="SMTP / Email" subtitle="Outbound transactional email delivery." saving={mut.isPending} onSave={() => mut.mutate({ section: "smtp", values: smtp })}>
            <Field label="Host"><input value={smtp.host || ""} onChange={(e) => setSmtp({ ...smtp, host: e.target.value })} className={inputCls} /></Field>
            <Field label="Port"><input type="number" value={smtp.port || 587} onChange={(e) => setSmtp({ ...smtp, port: +e.target.value })} className={inputCls} /></Field>
            <Field label="Username"><input value={smtp.username || ""} onChange={(e) => setSmtp({ ...smtp, username: e.target.value })} className={inputCls} /></Field>
            <Field label="From Email"><input value={smtp.from_email || ""} onChange={(e) => setSmtp({ ...smtp, from_email: e.target.value })} className={inputCls} /></Field>
          </Section>
        </TabsContent>

        <TabsContent value="payment" className="mt-6">
          <Section title="Payment Gateways" subtitle="Stripe, Razorpay, PayPal, App-store IAP." saving={mut.isPending} onSave={() => mut.mutate({ section: "payment", values: payment })}>
            <Field label="Stripe Publishable Key"><input value={payment.stripe_publishable_key || ""} onChange={(e) => setPayment({ ...payment, stripe_publishable_key: e.target.value })} className={inputCls} /></Field>
            <Field label="Razorpay Key ID"><input value={payment.razorpay_key_id || ""} onChange={(e) => setPayment({ ...payment, razorpay_key_id: e.target.value })} className={inputCls} /></Field>
            <Field label="Default Currency">
              <select value={payment.currency || "INR"} onChange={(e) => setPayment({ ...payment, currency: e.target.value })} className={inputCls}>
                {["INR", "USD", "EUR", "GBP", "AED"].map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
          </Section>
        </TabsContent>

        <TabsContent value="security" className="mt-6">
          <Section title="Security" subtitle="Authentication policy and rate limits." saving={mut.isPending} onSave={() => mut.mutate({ section: "security", values: security })}>
            <Field label="Session Timeout (mins)"><input type="number" value={security.session_timeout || 60} onChange={(e) => setSecurity({ ...security, session_timeout: +e.target.value })} className={inputCls} /></Field>
            <Field label="Password Min Length"><input type="number" value={security.password_min_length || 8} onChange={(e) => setSecurity({ ...security, password_min_length: +e.target.value })} className={inputCls} /></Field>
            <Field label="Rate Limit / min"><input type="number" value={security.rate_limit || 100} onChange={(e) => setSecurity({ ...security, rate_limit: +e.target.value })} className={inputCls} /></Field>
            <Field label="MFA Enabled">
              <label className="flex items-center gap-2 h-10">
                <input type="checkbox" checked={!!security.mfa_enabled} onChange={(e) => setSecurity({ ...security, mfa_enabled: e.target.checked })} className="accent-[#E50914]" />
                <span className="text-sm">Require MFA for admin accounts</span>
              </label>
            </Field>
          </Section>
        </TabsContent>

        <TabsContent value="cdn" className="mt-6">
          <Section title="CDN & Delivery" subtitle="Edge network powering your HLS/DASH streams." saving={mut.isPending} onSave={() => mut.mutate({ section: "cdn", values: cdn })}>
            <Field label="Provider">
              <select value={cdn.provider || "AWS CloudFront"} onChange={(e) => setCdn({ ...cdn, provider: e.target.value })} className={inputCls}>
                {["AWS CloudFront", "Cloudflare", "Akamai", "Fastly", "Bunny CDN"].map((p) => <option key={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Origin URL"><input value={cdn.origin_url || ""} onChange={(e) => setCdn({ ...cdn, origin_url: e.target.value })} className={inputCls} /></Field>
            <Field label="Edge Regions"><input value={cdn.edge_regions || ""} onChange={(e) => setCdn({ ...cdn, edge_regions: e.target.value })} className={inputCls} /></Field>
          </Section>
        </TabsContent>

        <TabsContent value="drm" className="mt-6">
          <Section title="DRM" subtitle="Widevine / FairPlay / PlayReady key server configuration." saving={mut.isPending} onSave={() => toast.info("DRM configuration coming soon")}>
            <Field label="Widevine License URL"><input placeholder="https://widevine.provider/license" className={inputCls} /></Field>
            <Field label="FairPlay Certificate URL"><input placeholder="https://fairplay.provider/cert" className={inputCls} /></Field>
            <Field label="PlayReady License URL"><input placeholder="https://playready.provider/license" className={inputCls} /></Field>
          </Section>
        </TabsContent>
      </Tabs>
    </div>
  );
}

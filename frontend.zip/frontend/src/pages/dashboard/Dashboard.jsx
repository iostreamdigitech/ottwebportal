import React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, Legend, BarChart, Bar,
} from "recharts";
import { motion } from "framer-motion";
import PageHeader from "../../components/common/PageHeader";
import StatCard from "../../components/common/StatCard";
import StatusBadge from "../../components/common/StatusBadge";
import { dashboardService } from "../../services";
import { formatCurrency, formatDate, formatNumber, initials } from "../../utils";
import { Download, Filter } from "lucide-react";

const RED = "#E50914";
const PIE_COLORS = ["#E50914", "#F59E0B", "#0EA5E9", "#8B5CF6", "#10B981"];

function ChartCard({ title, subtitle, action, children, className = "" }) {
  return (
    <div className={`bg-[#141414] border border-[#27272A] rounded-sm p-5 ${className}`}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-medium">{subtitle}</div>
          <div className="font-display uppercase text-lg tracking-widest text-white mt-0.5">{title}</div>
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

export default function Dashboard() {
  const { data: statsData, isLoading: sL } = useQuery({ queryKey: ["dash", "stats"], queryFn: () => dashboardService.stats() });
  const { data: chartsData, isLoading: cL } = useQuery({ queryKey: ["dash", "charts"], queryFn: () => dashboardService.charts() });
  const { data: recentData } = useQuery({ queryKey: ["dash", "recent"], queryFn: () => dashboardService.recent() });

  const cards = statsData?.cards || [];

  return (
    <div className="space-y-8">
      <PageHeader
        title="Command Center"
        subtitle="Real-time pulse across content, revenue, audience and system health."
        actions={
          <>
            <button data-testid="dashboard-filter-button" className="h-9 px-3 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Filter className="w-3.5 h-3.5" /> Last 30 days
            </button>
            <button data-testid="dashboard-export-button" className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Download className="w-3.5 h-3.5" /> Export
            </button>
          </>
        }
      />

      {/* Stat grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {sL && [...Array(10)].map((_, i) => (
          <div key={i} className="h-[136px] bg-[#141414] border border-[#27272A] rounded-sm animate-pulse" />
        ))}
        {cards.map((c, i) => <StatCard key={c.key} {...c} index={i} />)}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartCard title="Revenue Trend" subtitle="12-month" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={chartsData?.revenue_trend || []}>
              <defs>
                <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={RED} stopOpacity={0.4} />
                  <stop offset="95%" stopColor={RED} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#27272A" strokeDasharray="2 4" vertical={false} />
              <XAxis dataKey="month" stroke="#52525B" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#52525B" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: "#0A0A0A", border: "1px solid #27272A", borderRadius: 4, fontSize: 12 }} labelStyle={{ color: "#fff" }} />
              <Area type="monotone" dataKey="revenue" stroke={RED} strokeWidth={2} fill="url(#rev)" />
              <Line type="monotone" dataKey="target" stroke="#3F3F46" strokeDasharray="4 4" strokeWidth={1.5} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Device Usage" subtitle="Distribution">
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie
                data={chartsData?.device_usage || []}
                dataKey="value"
                nameKey="name"
                innerRadius={60}
                outerRadius={95}
                stroke="#0A0A0A"
                strokeWidth={2}
              >
                {(chartsData?.device_usage || []).map((_, i) => (
                  <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "#0A0A0A", border: "1px solid #27272A", borderRadius: 4, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartCard title="User Growth" subtitle="New vs Active">
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={chartsData?.user_growth || []}>
              <CartesianGrid stroke="#27272A" strokeDasharray="2 4" vertical={false} />
              <XAxis dataKey="month" stroke="#52525B" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#52525B" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: "#0A0A0A", border: "1px solid #27272A", fontSize: 12 }} />
              <Line dataKey="active" stroke="#0EA5E9" strokeWidth={2} dot={{ r: 2 }} />
              <Line dataKey="new" stroke={RED} strokeWidth={2} dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Content Growth" subtitle="Monthly Uploads">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={chartsData?.content_growth || []}>
              <CartesianGrid stroke="#27272A" strokeDasharray="2 4" vertical={false} />
              <XAxis dataKey="month" stroke="#52525B" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#52525B" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: "#0A0A0A", border: "1px solid #27272A", fontSize: 12 }} />
              <Bar dataKey="movies" fill={RED} radius={[2, 2, 0, 0]} />
              <Bar dataKey="series" fill="#F59E0B" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Subscription Mix" subtitle="Active Plans">
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={chartsData?.subscription_distribution || []}
                dataKey="value"
                nameKey="name"
                innerRadius={0}
                outerRadius={90}
                stroke="#0A0A0A"
                strokeWidth={2}
              >
                {(chartsData?.subscription_distribution || []).map((_, i) => (
                  <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "#0A0A0A", border: "1px solid #27272A", fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Recent tables */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartCard title="Top Movies" subtitle="This Week" className="lg:col-span-1">
          <div className="space-y-2">
            {(chartsData?.top_movies || []).map((m, i) => (
              <div key={m.title} className="flex items-center justify-between p-2 hover:bg-[#1E1E1E] rounded-sm">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="font-display text-xl text-zinc-600 w-6">{i + 1}</div>
                  <div className="min-w-0">
                    <div className="text-sm text-white truncate">{m.title}</div>
                    <div className="text-[10px] uppercase tracking-widest text-zinc-500">★ {m.rating}</div>
                  </div>
                </div>
                <div className="text-xs text-zinc-400 font-mono">{formatNumber(m.views)}</div>
              </div>
            ))}
          </div>
        </ChartCard>

        <ChartCard title="Recent Payments" subtitle="Last 24h">
          <div className="space-y-2">
            {(recentData?.recent_payments || []).map((p) => (
              <div key={p.id} className="flex items-center justify-between p-2 hover:bg-[#1E1E1E] rounded-sm">
                <div className="min-w-0">
                  <div className="text-sm text-white truncate">{p.user}</div>
                  <div className="text-[10px] text-zinc-500 uppercase tracking-widest">{p.plan}</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-xs font-mono text-white">{formatCurrency(p.amount)}</div>
                  <StatusBadge status={p.status} />
                </div>
              </div>
            ))}
          </div>
        </ChartCard>

        <ChartCard title="Recent Errors" subtitle="System Log">
          <div className="space-y-2">
            {(recentData?.recent_errors || []).map((e) => (
              <div key={e.id} className="p-2 hover:bg-[#1E1E1E] rounded-sm">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-mono text-[#E50914]">{e.code}</div>
                  <StatusBadge status={e.severity === "error" ? "failed" : "pending"} />
                </div>
                <div className="text-sm text-white mt-1">{e.message}</div>
                <div className="text-[10px] text-zinc-500 uppercase tracking-widest mt-0.5">{formatDate(e.date)}</div>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>

      {/* Recent users grid */}
      <ChartCard title="Recent Users" subtitle="Latest sign-ups">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {(recentData?.recent_users || []).slice(0, 6).map((u) => (
            <motion.div
              key={u.id}
              whileHover={{ y: -2 }}
              className="border border-[#27272A] hover:border-[#3F3F46] rounded-sm p-3 flex items-center gap-3"
            >
              <div className="w-9 h-9 rounded-sm bg-gradient-to-br from-[#E50914] to-[#7a0208] flex items-center justify-center text-xs font-bold text-white">
                {initials(u.name)}
              </div>
              <div className="min-w-0">
                <div className="text-sm text-white truncate">{u.name}</div>
                <div className="text-[10px] text-zinc-500 uppercase tracking-widest">{u.plan}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </ChartCard>
    </div>
  );
}

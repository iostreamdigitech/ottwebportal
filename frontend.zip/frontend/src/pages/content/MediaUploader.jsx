import React, { useEffect, useState,useRef } from "react";
import { Save, ArrowLeft,  Upload,
  Image as ImageIcon, Trash2 } from "lucide-react";
export default function MediaUploader({
    title,
    value,
    onChange,
    accept = "image/*",
    aspect = "",
    size = "",
}) {

    const inputRef = useRef(null);

    const handleSelect = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const preview = URL.createObjectURL(file);

        onChange({
            file,
            preview,
            url: preview,
        });
    };

    const imageSrc =
        value?.preview ||
        value?.url ||
        value;

    return (
        <div className="rounded-lg border border-zinc-800 bg-[#0D0D0D] overflow-hidden">

            <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
                <div>
                    <h4 className="text-sm font-semibold text-white">
                        {title}
                    </h4>

                    {(aspect || size) && (
                        <p className="text-xs text-zinc-500 mt-1">
                            {aspect}
                            {aspect && size && " • "}
                            {size}
                        </p>
                    )}
                </div>
            </div>

            <div className="p-5">

                <div className="aspect-[2/3] rounded-md border border-dashed border-zinc-700 overflow-hidden bg-zinc-900">

                    {imageSrc ? (
                        <img
                            src={imageSrc}
                            alt={title}
                            className="w-full h-full object-cover"
                        />
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-zinc-500">
                            <ImageIcon className="w-10 h-10 mb-3" />
                            <p className="text-xs">No Image</p>
                        </div>
                    )}

                </div>

                <div className="flex gap-2 mt-4">

                    <button
                        type="button"
                        onClick={() => inputRef.current.click()}
                        className="flex-1 h-10 rounded bg-red-600 hover:bg-red-700 text-white"
                    >
                        Upload
                    </button>

                    {imageSrc && (
                        <button
                            type="button"
                            onClick={() => onChange(null)}
                            className="h-10 w-10 rounded border border-zinc-700"
                        >
                            <Trash2 className="text-red-400" size={16}/>
                        </button>
                    )}

                </div>

                <input
                    hidden
                    ref={inputRef}
                    type="file"
                    accept={accept}
                    onChange={handleSelect}
                />

            </div>
        </div>
    );
}
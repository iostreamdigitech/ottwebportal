import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Search, Filter, Trash2, Eye, Edit3, Copy, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import PageHeader from "../../components/common/PageHeader";
import StatusBadge from "../../components/common/StatusBadge";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import EmptyState from "../../components/common/EmptyState";
import { GridSkeleton } from "../../components/common/LoadingSkeleton";
import { contentService } from "../../services";
import { formatDate, formatNumber } from "../../utils";
import { cn } from "../../lib/utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";

const TYPE_META = {
  movies: { type: "MOVIE", title: "Movies", subtitle: "Feature films catalog" },
  series: { type: "series", title: "Series", subtitle: "Multi-season shows and originals" },
  episodes: { type: "episode", title: "Episodes", subtitle: "Individual episodes across all series" },
  live: { type: "live", title: "Live TV", subtitle: "Live channels" },
  shorts: { type: "short", title: "Short Videos", subtitle: "Bite-sized content" },
};

const STATUSES = ["all", "draft", "review", "approved", "published", "rejected", "archived"];

export default function ContentList() {
  const { type: routeType } = useParams();
  const nav = useNavigate();
  const meta = TYPE_META[routeType] || TYPE_META.movies;
  const qc = useQueryClient();

  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [confirmDel, setConfirmDel] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ["content", meta.type, q, status],
    queryFn: () => contentService.list({ type: meta.type, q: q || undefined, status: status !== "all" ? status : undefined, page_size: 60 }),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => contentService.delete(id),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["content"] }); setConfirmDel(null); },
  });
const items = data?.data?.content || [];
console.log("API Response:", data);
console.log("Items:", data?.data?.content);

  return (
    <div className="space-y-6">
      <PageHeader
        title={meta.title}
        subtitle={meta.subtitle}
        actions={
          <>
            <button className="h-9 px-3 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Filter className="w-3.5 h-3.5" /> More filters
            </button>
            <button data-testid="content-add-button" onClick={() => nav(`/content/${routeType}/new`)} className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Plus className="w-3.5 h-3.5" /> Add {meta.type}
            </button>
          </>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            data-testid="content-search-input"
            placeholder={`Search ${meta.title.toLowerCase()}…`}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-full bg-[#141414] border border-[#27272A] rounded-sm pl-10 pr-4 py-2.5 text-sm text-white focus:border-[#E50914] focus:outline-none"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger data-testid="content-status-filter" className="w-[160px] bg-[#141414] border-[#27272A] text-white h-10">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-[#141414] border-[#27272A] text-white">
            {STATUSES.map((s) => <SelectItem key={s} value={s} className="focus:bg-[#1E1E1E] focus:text-white capitalize">{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Grid */}
      {isLoading ? <GridSkeleton /> : (items.length ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {items.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.02 * i, duration: 0.3 }}
              className="group relative bg-[#141414] border border-[#27272A] rounded-sm overflow-hidden hover:border-[#3F3F46] transition-colors"
              data-testid={`content-card-${c.id}`}
            >
              <div className="aspect-[2/3] relative overflow-hidden bg-[#0A0A0A]">
                {c.poster ? (
                  <img
                    src={c.poster}
                    alt={c.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-700 text-6xl font-display">
                    {c.title?.[0] || "?"}
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-90" />

                {/* Overlay meta */}
                <div className="absolute top-2 left-2 right-2 flex justify-between items-start">
                  <StatusBadge status={c.status} />
                  {c.drm && <span className="text-[9px] uppercase tracking-widest bg-black/60 backdrop-blur border border-[#27272A] px-1.5 py-0.5 rounded-sm text-emerald-400">DRM</span>}
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <div className="text-[10px] uppercase tracking-widest text-zinc-400 mb-0.5">{c.year} · {c.language} · {c.quality}</div>
                  <div className="font-display uppercase text-white text-base tracking-wide leading-tight line-clamp-2">{c.title}</div>
                  <div className="flex items-center justify-between mt-1.5">
                    <div className="text-[10px] text-zinc-400 uppercase tracking-widest">★ {c.rating || "—"}</div>
                    <div className="text-[10px] text-zinc-400 uppercase tracking-widest">{formatNumber(c.views)} views</div>
                  </div>
                </div>

                {/* Hover actions */}
                <div className="absolute inset-0 flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 backdrop-blur-sm">
                  <button data-testid={`content-edit-${c.id}`} onClick={() => nav(`/content/${routeType}/${c.id}`)} className="w-9 h-9 bg-[#E50914] hover:bg-[#F40612] rounded-sm flex items-center justify-center">
                    <Edit3 className="w-4 h-4 text-white" />
                  </button>
                  <button className="w-9 h-9 bg-[#1E1E1E] hover:bg-[#27272A] border border-[#27272A] rounded-sm flex items-center justify-center">
                    <Eye className="w-4 h-4 text-white" />
                  </button>
                  <button data-testid={`content-delete-${c.id}`} onClick={() => setConfirmDel(c)} className="w-9 h-9 bg-[#1E1E1E] hover:bg-[#27272A] border border-[#27272A] rounded-sm flex items-center justify-center">
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : <EmptyState title={`No ${meta.title.toLowerCase()} yet`} subtitle="Get started by adding your first title." />)}

      <ConfirmDialog
        open={!!confirmDel}
        onOpenChange={(v) => !v && setConfirmDel(null)}
        title={`Delete "${confirmDel?.title}"?`}
        description="This will permanently delete this title and all its episodes (if applicable)."
        onConfirm={() => confirmDel && deleteMut.mutate(confirmDel.id)}
        confirmText="Delete"
      />
    </div>
  );
}

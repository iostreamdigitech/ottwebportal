import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Save, ArrowLeft,  Upload,
  Image as ImageIcon, Trash2 } from "lucide-react";


import MediaUploader from "./MediaUploader.jsx";
import PageHeader from "../../components/common/PageHeader";

import {
  authService,
  dashboardService,
  userService,
  bannerService,
  contentService,
  contentServiceData,
  categoryService,
  genreService,
  languageService,
  castService,
  crewService,
  planService,
  adminService,
  settingsService,
  notificationService,
} from "../../services";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";

const TYPE_META = {
  movies: "movie", series: "series", episodes: "episode", live: "live", shorts: "short",
};

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-1.5 font-medium">{label}</label>
      {children}
    </div>
  );
}

const inputCls = "w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none";

export default function ContentForm() {
  const { type: routeType, id } = useParams();
  const nav = useNavigate();
  const qc = useQueryClient();
 const [castInput,setCastInput] = useState("");
const [crewInput,setCrewInput] = useState("");
const [tagsInput,setTagsInput] = useState("");
const [geoInput,setGeoInput] = useState("");
  const isNew = id === "new";
  const backendType = TYPE_META[routeType] || "movie";

  const [form, setForm] = useState({
    title: "", slug: "", description: "", type: backendType,
    
     "contentType": backendType.toUpperCase(),
    language: "English", genres: [], tags: [], country: "USA", year: 2025, duration: 90,
    age_rating: "U/A 13+", cast: [], crew: [], director: "", producer: "",
      monetization: {
    type: "FREE",
    amount: "",
    iapAmount: "",
    iapProductIdIos: "",
    iapProductIdAndroid: "",
  },
  media: {
    posters: {
        desktop: "",
        mobile: "",
        tv: "",
    },

    banners: {
        desktop: "",
        mobile: "",
        tv: "",
    },

    thumbnails: {
        web: "",
        mobile: "",
        tv: "",
    },

    logos: {
        transparent: "",
        dark: "",
        light: "",
    },

    videos: {
        trailer: "",
        main: "",
        preview: "",
    }
},
security: {
  type: "NONE", // NONE | DRM | ENCRYPTION
  encryptionKey: "",
},
    quality: "1080p", drm: false, is_hdr: false, downloadable: true, status: "draft",
    visibility: "public", geo_restriction: [], meta_title: "", meta_description: "",
  });

const {
  data: categories = [],
  isLoading,
  error,
} = useQuery({
  queryKey: ["categories"],
  queryFn: async () => {
    console.log("React Query calling Categories");
    return await contentServiceData.getAllCategories();
  },
});

console.log({ categories, isLoading, error });
  const { data: contentTypes=[] } = useQuery({
    queryKey:["contentTypes"],
    queryFn:()=>contentServiceData.getAllContentType()
});

  const { data: existing } = useQuery({
    queryKey: ["content", id],
    queryFn: () => contentService.get(id),
    enabled: !isNew,
  });

  const { data: genres = [] } = useQuery({ queryKey: ["genres"], queryFn: () => contentServiceData.getAllGeneres() });
  const { data: languages = [] } = useQuery({ queryKey: ["languages"], queryFn: () => contentServiceData.getAllLanguages() });
  const { data: cast = [] } = useQuery({ queryKey: ["cast"], queryFn: () => castService.list() });
  const { data: crew = [] } = useQuery({ queryKey: ["crew"], queryFn: () => crewService.list() });

useEffect(() => {
  if (!existing) return;

  setForm(existing);

  setCastInput((existing.cast || []).join(", "));
  setCrewInput((existing.crew || []).join(", "));
  setTagsInput((existing.tags || []).join(", "));
  setGeoInput((existing.geo_restriction || []).join(", "));
}, [existing]);

const saveMut = useMutation({
  mutationFn: ({ metadata, files }) => {
    if (isNew) {
      return contentService.createContent(files, metadata);
    }

    return contentService.updateContent(id, files, metadata);
  },

  onSuccess: () => {
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: ["content"] });
    nav(`/content/${routeType}`);
  },

  onError: (e) => {
    toast.error("Save failed", {
      description: e?.detail || "Try again",
    });
  },
});

  const deleteMut = useMutation({
    mutationFn: () => contentService.delete(id),
    onSuccess: () => { toast.success("Deleted"); nav(`/content/${routeType}`); },
  });

  const setF = (k, v) => setForm((f) => ({ ...f, [k]: v }));
const updateMedia = (section, device, value) => {
  setForm((prev) => ({
    ...prev,
    media: {
      ...prev.media,
      [section]: {
        ...prev.media[section],
        [device]: value,
      },
    },
  }));
};
const submit = async (e) => {
  e.preventDefault();

  const metadata = {
    ...form,
    contentType: backendType.toUpperCase(),

    year: Number(form.year),
    duration: Number(form.duration),

    genreIds: (form.genres || []).map(Number),
    categoryIds: form.category ? [Number(form.category)] : [],
    offerIds: (form.offers || []).map(Number),

    rating: form.age_rating,
    longDescription: form.description,
    releaseDate: form.release_date,

    metaTitle: form.meta_title,
    metaDescription: form.meta_description,

    geoRestrictions: form.geo_restriction,

    hdr: form.is_hdr,
    drm: form.security?.type === "DRM",
    quality: form.quality,
    downloadable: form.downloadable,
    visibility: form.visibility,

    cast: form.cast,
    crew: form.crew,
    tags: form.tags,

    monetization: form.monetization,
  };

  try {
    //---------------------------------------------
    // STEP 1 : CREATE / UPDATE CONTENT
    //---------------------------------------------
    let contentId = id;

    if (isNew) {
      const response = await contentService.create(metadata);

      // Adjust this according to your ApiResponse
      contentId = response.data.id;

      toast.success("Content created successfully");
    } else {
      await contentService.update(id, metadata);

      contentId = id;

      toast.success("Content updated successfully");
    }

    //---------------------------------------------
    // STEP 2 : PREPARE MEDIA REQUEST
    //---------------------------------------------
console.log(form.media);
    const assets = [];
    const files = [];

const addAsset = (mediaObj, assetType, platform) => {
    if (!mediaObj?.file) return;

    assets.push({
        file: mediaObj.file,
        assetType,
        platform
    });
};
    // Posters
addAsset(form.media.posters.desktop, "POSTER", "WEB");
addAsset(form.media.posters.mobile, "POSTER", "MOBILE");
addAsset(form.media.posters.tv, "POSTER", "TV");

addAsset(form.media.banners.desktop, "BANNER", "WEB");
addAsset(form.media.banners.mobile, "BANNER", "MOBILE");
addAsset(form.media.banners.tv, "BANNER", "TV");

addAsset(form.media.thumbnails.web, "THUMBNAIL", "WEB");
addAsset(form.media.thumbnails.mobile, "THUMBNAIL", "MOBILE");
addAsset(form.media.thumbnails.tv, "THUMBNAIL", "TV");

    // Logos
   

    //---------------------------------------------
    // STEP 3 : UPLOAD MEDIA (ASYNC)
    //---------------------------------------------

  if (assets.length > 0) {
    console.log("Assets", assets);

assets.forEach(a => {
    console.log(
        a.assetType,
        a.platform,
        a.file,
        a.file instanceof File
    );
});
    contentService
        .uploadAssets(contentId, assets)
        .then(() => {
            toast.success("Media uploaded successfully");
        })
        .catch((err) => {
            console.error(err);
            toast.error("Media upload failed");
        });
}
    //---------------------------------------------
    // STEP 4 : REDIRECT
    //---------------------------------------------

    qc.invalidateQueries({
      queryKey: ["content"],
    });

    nav(`/content/${routeType}`);

  } catch (error) {
    console.error(error);

    toast.error(
      error?.response?.data?.message ||
      "Failed to save content"
    );
  }
};
const generateSlug = (text) => {
  return text
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
};
  return (
    <form onSubmit={submit} className="space-y-6">
      <PageHeader
        title={isNew ? `New ${backendType}` : form.title || "Edit"}
        subtitle={isNew ? "Fill in the metadata to publish a new title." : "Update metadata, cast, media and publishing state."}
        actions={
          <>
            <button type="button" onClick={() => nav(-1)} className="h-9 px-3 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
            {!isNew && (
              <button type="button" onClick={() => deleteMut.mutate()} className="h-9 px-3 border border-[#27272A] hover:border-red-500 text-red-400 rounded-sm text-xs uppercase tracking-widest flex items-center gap-2">
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </button>
            )}
            <button data-testid="content-save-button" type="submit" disabled={saveMut.isPending} className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Save className="w-3.5 h-3.5" /> {saveMut.isPending ? "Saving…" : "Save"}
            </button>
          </>
        }
      />

      <Tabs defaultValue="overview">
        <TabsList className="bg-transparent border-b border-[#27272A] w-full justify-start rounded-none h-auto p-0 gap-1">
        {[
  "overview",
  "media",
  "cast-crew",
  "monetization",
  "seo",
  "publishing",
  "advanced",
].map((t) => (
            <TabsTrigger
              key={t}
              value={t}
              data-testid={`tab-${t}`}
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#E50914] data-[state=active]:bg-transparent data-[state=active]:text-white text-zinc-500 uppercase tracking-[0.2em] text-xs px-4 py-3"
            >
              {t.replace("-", " & ")}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-5">
             <Field label="Title">
  <input
    required
    value={form.title}
    onChange={(e) => {
      const title = e.target.value;

      setForm((prev) => ({
        ...prev,
        title,
        slug: generateSlug(title),
      }));
    }}
    className={inputCls}
  />
</Field>
              <Field label="Slug">
                <input value={form.slug} onChange={(e) => setF("slug", e.target.value)} placeholder="auto-generated" className={inputCls} />
              </Field>
              <Field label="Short Description">
  <textarea
    value={form.shortDescription || ""}
    onChange={(e) => setF("shortDescription", e.target.value)}
    rows={3}
    maxLength={250}
    placeholder="Enter a short synopsis (maximum 250 characters)"
    className={inputCls + " resize-none"}
  />

  <div className="mt-1 flex justify-between text-xs text-zinc-500">
    <span>Displayed in content cards and previews</span>
    <span>{(form.shortDescription || "").length}/250</span>
  </div>
</Field>
              <Field label="Description">
                <textarea value={form.description} onChange={(e) => setF("description", e.target.value)} rows={5} className={inputCls + " resize-none"} />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Production House">
  <input
    type="text"
    value={form.productionHouse || ""}
    onChange={(e) => setF("productionHouse", e.target.value)}
    placeholder="e.g. Sun Pictures, Lyca Productions"
    className={inputCls}
  />
</Field>
                <Field label="Year"><input type="number" value={form.year} onChange={(e) => setF("year", +e.target.value)} className={inputCls} /></Field>
                <Field label="Duration (mins)"><input type="number" value={form.duration} onChange={(e) => setF("duration", +e.target.value)} className={inputCls} /></Field>
                <Field label="Country"><input value={form.country} onChange={(e) => setF("country", e.target.value)} className={inputCls} /></Field>
                <Field label="Age Rating">
                  <select value={form.age_rating} onChange={(e) => setF("age_rating", e.target.value)} className={inputCls}>
                    {["U", "U/A 7+", "U/A 13+", "U/A 16+", "A"].map((v) => <option key={v}>{v}</option>)}
                  </select>
                </Field>
              </div>
            </div>

            <div className="space-y-5">
             <Field label="Category">
  <select
    value={form.category || ""}
    onChange={(e) => setF("category", e.target.value)}
    className={inputCls}
  >
    <option value="">Select Category</option>

    {categories.map((c) => (
      <option key={c.id} value={c.id}>
        {c.categoryName}
      </option>
    ))}
  </select>
</Field>
             <Field label="Language">
  <select
    value={form.language || ""}
    onChange={(e) => setF("language", e.target.value)}
    className={inputCls}
  >
    <option value="">Select Language</option>

    {languages.map((l) => (
      <option key={l.id} value={l.id}>
        {l.languageName}
      </option>
    ))}
  </select>
</Field>
            <Field label="Genres">
  <select
    multiple
    value={form.genres || []}
    className={inputCls + " h-36"}
    onChange={(e) => {
      const values = Array.from(
        e.target.selectedOptions,
        (option) => option.value
      );
      setF("genres", values);
    }}
  >
    {genres.map((genre) => (
      <option key={genre.id} value={genre.id}>
        {genre.genreName}
      </option>
    ))}
  </select>

  <p className="text-xs text-zinc-500 mt-1">
    Hold Ctrl (Windows) or Cmd (Mac) to select multiple genres.
  </p>
</Field>
              <Field label="Tags">
                <input value={(form.tags || []).join(", ")} onChange={(e) => setF("tags", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} className={inputCls} />
              </Field>
              <Field label="Status">
                <select value={form.status} onChange={(e) => setF("status", e.target.value)} className={inputCls}>
                  {["draft", "review", "approved", "published", "rejected", "archived"].map((s) => <option key={s} value={s} className="capitalize">{s}</option>)}
                </select>
              </Field>
              <Field label="Visibility">
                <select value={form.visibility} onChange={(e) => setF("visibility", e.target.value)} className={inputCls}>
                  <option value="public">Public</option>
                  <option value="premium">Premium Only</option>
                  <option value="private">Private</option>
                </select>
              </Field>
            </div>
          </div>
        </TabsContent>

        {/* Media */}
        <TabsContent value="media" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <TabsContent value="media" className="mt-6">
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

    {/* Posters */}
    <MediaUploader
      title="Desktop Poster"
      value={form.media.posters.desktop}
      onChange={(file) => updateMedia("posters", "desktop", file)}
    />

    <MediaUploader
      title="Mobile Poster"
      value={form.media.posters.mobile}
      onChange={(file) => updateMedia("posters", "mobile", file)}
    />

    <MediaUploader
      title="TV Poster"
      value={form.media.posters.tv}
      onChange={(file) => updateMedia("posters", "tv", file)}
    />

    {/* Banners */}
    <MediaUploader
      title="Desktop Banner"
      value={form.media.banners.desktop}
      onChange={(file) => updateMedia("banners", "desktop", file)}
    />

    <MediaUploader
      title="Mobile Banner"
      value={form.media.banners.mobile}
      onChange={(file) => updateMedia("banners", "mobile", file)}
    />

    <MediaUploader
      title="TV Banner"
      value={form.media.banners.tv}
      onChange={(file) => updateMedia("banners", "tv", file)}
    />

    {/* Thumbnails */}
    <MediaUploader
      title="Web Thumbnail"
      value={form.media.thumbnails.web}
      onChange={(file) => updateMedia("thumbnails", "web", file)}
    />

    <MediaUploader
      title="Mobile Thumbnail"
      value={form.media.thumbnails.mobile}
      onChange={(file) => updateMedia("thumbnails", "mobile", file)}
    />

    <MediaUploader
      title="TV Thumbnail"
      value={form.media.thumbnails.tv}
      onChange={(file) => updateMedia("thumbnails", "tv", file)}
    />

    {/* Logos */}
    <MediaUploader
      title="Transparent Logo"
      value={form.media.logos.transparent}
      onChange={(file) => updateMedia("logos", "transparent", file)}
    />

    <MediaUploader
      title="Dark Logo"
      value={form.media.logos.dark}
      onChange={(file) => updateMedia("logos", "dark", file)}
    />

    <MediaUploader
      title="Light Logo"
      value={form.media.logos.light}
      onChange={(file) => updateMedia("logos", "light", file)}
    />

    {/* Videos */}
    

    <MediaUploader
      title="Preview Video"
      accept="video/*"
      value={form.media.videos.preview}
      onChange={(file) => updateMedia("videos", "preview", file)}
    />

  </div>
</TabsContent>   


     <Field label="Thumbnail URL"><input value={form.thumbnail} onChange={(e) => setF("thumbnail", e.target.value)} className={inputCls} /></Field>
            <Field label="Video HLS/MP4 URL"><input value={form.video_url} onChange={(e) => setF("video_url", e.target.value)} className={inputCls} /></Field>
            <Field label="Trailer URL"><input value={form.trailer_url} onChange={(e) => setF("trailer_url", e.target.value)} className={inputCls} /></Field>
            <Field label="Quality">
              <select value={form.quality} onChange={(e) => setF("quality", e.target.value)} className={inputCls}>
                {["4K", "1080p", "720p", "480p", "360p"].map((q) => <option key={q}>{q}</option>)}
              </select>
            </Field>
          </div>
          {form.poster && (
            <div className="mt-6 border border-[#27272A] rounded-sm overflow-hidden max-w-xs">
              <img src={form.poster} alt="Poster preview" className="w-full aspect-[2/3] object-cover" />
            </div>
          )}
        </TabsContent>

        {/* Cast & Crew */}
        <TabsContent value="cast-crew" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Field label="Director"><input value={form.director} onChange={(e) => setF("director", e.target.value)} placeholder={crew[0]?.name} className={inputCls} /></Field>
            <Field label="Producer"><input value={form.producer} onChange={(e) => setF("producer", e.target.value)} className={inputCls} /></Field>
           <Field label="Cast">

<input
    value={castInput}
    onChange={(e)=>{
        const value=e.target.value;
        setCastInput(value);

        setF(
            "cast",
            value
              .split(",")
              .map(x=>x.trim())
              .filter(Boolean)
        );
    }}
    className={inputCls}
/>

</Field>
            <Field label="Crew (comma separated)">
              <input value={(form.crew || []).join(", ")} 
              onChange={(e) => 
              setF("crew", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} className={inputCls} /></Field>
          </div>
        </TabsContent>
        <TabsContent value="monetization" className="mt-6">

  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

    <Field label="Monetization Type">
      <select
        value={form.monetization.type}
        onChange={(e) =>
          setForm((prev) => ({
            ...prev,
            monetization: {
              ...prev.monetization,
              type: e.target.value,
            },
          }))
        }
        className={inputCls}
      >
        <option value="FREE">Free</option>
        <option value="SUBSCRIPTION">Subscription</option>
        <option value="RENT">Rent</option>
      </select>
    </Field>

  </div>

  {form.monetization.type === "RENT" && (

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">

      <Field label="Amount">
        <input
          type="number"
          value={form.monetization.amount}
          onChange={(e) =>
            setForm((prev) => ({
              ...prev,
              monetization: {
                ...prev.monetization,
                amount: e.target.value,
              },
            }))
          }
          className={inputCls}
        />
      </Field>

      <Field label="IAP Amount">
        <input
          type="number"
          value={form.monetization.iosAmount}
          onChange={(e) =>
            setForm((prev) => ({
              ...prev,
              monetization: {
                ...prev.monetization,
                iosAmount: e.target.value,
              },
            }))
          }
          className={inputCls}
        />
      </Field>

      <Field label="IAP Product ID (iOS)">
        <input
          value={form.monetization.iapProductIdIos}
          onChange={(e) =>
            setForm((prev) => ({
              ...prev,
              monetization: {
                ...prev.monetization,
                iapProductIdIos: e.target.value,
              },
            }))
          }
          className={inputCls}
          placeholder="com.company.movie.rent.ios"
        />
      </Field>

      <Field label="IAP Product ID (Android)">
        <input
          value={form.monetization.iapProductIdAndroid}
          onChange={(e) =>
            setForm((prev) => ({
              ...prev,
              monetization: {
                ...prev.monetization,
                iapProductIdAndroid: e.target.value,
              },
            }))
          }
          className={inputCls}
          placeholder="movie_rent_android"
        />
      </Field>

    </div>

  )}

</TabsContent>

        {/* SEO */}
        <TabsContent value="seo" className="mt-6">
          <div className="grid grid-cols-1 gap-6 max-w-2xl">
            <Field label="Meta Title"><input value={form.meta_title} onChange={(e) => setF("meta_title", e.target.value)} className={inputCls} /></Field>
            <Field label="Meta Description"><textarea rows={3} value={form.meta_description} onChange={(e) => setF("meta_description", e.target.value)} className={inputCls + " resize-none"} /></Field>
          </div>
        </TabsContent>

        {/* Publishing */}
        <TabsContent value="publishing" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl">
            <Field label="Release Date"><input type="date" value={form.release_date?.slice(0, 10) || ""} onChange={(e) => setF("release_date", e.target.value)} className={inputCls} /></Field>
            <Field label="Geo Restriction (comma separated countries)"><input value={(form.geo_restriction || []).join(", ")} onChange={(e) => setF("geo_restriction", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} className={inputCls} placeholder="US, UK, IN" /></Field>
            <div className="flex items-center gap-3">
              <input type="checkbox" checked={form.downloadable} onChange={(e) => setF("downloadable", e.target.checked)} className="accent-[#E50914]" />
              <span className="text-sm">Downloadable</span>
            </div>
          </div>
        </TabsContent>

        {/* Advanced / DRM */}
       {/* Advanced / Security */}
<TabsContent value="advanced" className="mt-6">

  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

    <Field label="Content Protection">
      <select
        value={form.security?.type || "NONE"}
        onChange={(e) =>
          setForm((prev) => ({
            ...prev,
            security: {
              ...prev.security,
              type: e.target.value,
            },
          }))
        }
        className={inputCls}
      >
        <option value="NONE">None</option>
        <option value="DRM">DRM</option>
        <option value="ENCRYPTION">Encryption</option>
      </select>
    </Field>

    <label className="flex items-center gap-3 p-4 border border-[#27272A] rounded-sm">
      <input
        type="checkbox"
        checked={form.is_hdr}
        onChange={(e) => setF("is_hdr", e.target.checked)}
        className="accent-[#E50914]"
      />
      <div>
        <div className="text-sm text-white">
          HDR / Dolby Vision
        </div>
        <div className="text-[11px] text-zinc-500">
          Enable HDR Playback
        </div>
      </div>
    </label>

  </div>

  {form.security?.type === "DRM" && (

    <div className="mt-6 rounded-md border border-[#27272A] bg-[#111111] p-4">

      <h3 className="text-white font-semibold mb-4">
        DRM Configuration
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

        <Field label="DRM Provider">
          <select
            value={form.security.drmProvider || ""}
            onChange={(e)=>
              setForm(prev=>({
                ...prev,
                security:{
                  ...prev.security,
                  drmProvider:e.target.value
                }
              }))
            }
            className={inputCls}
          >
            <option value="">Select Provider</option>
            <option value="WIDEVINE">Widevine</option>
            <option value="PLAYREADY">PlayReady</option>
            <option value="FAIRPLAY">FairPlay</option>
            <option value="MULTI_DRM">Multi DRM</option>
          </select>
        </Field>

        <Field label="License URL">
          <input
            value={form.security.licenseUrl || ""}
            onChange={(e)=>
              setForm(prev=>({
                ...prev,
                security:{
                  ...prev.security,
                  licenseUrl:e.target.value
                }
              }))
            }
            className={inputCls}
            placeholder="https://license.server.com"
          />
        </Field>

      </div>

    </div>

  )}

  {form.security?.type === "ENCRYPTION" && (

    <div className="mt-6">

      <Field label="Encryption Key">
        <input
          value={form.security.encryptionKey}
          onChange={(e)=>
            setForm(prev=>({
              ...prev,
              security:{
                ...prev.security,
                encryptionKey:e.target.value
              }
            }))
          }
          className={inputCls}
          placeholder="Enter AES Encryption Key"
        />
      </Field>

    </div>

  )}

</TabsContent>
      </Tabs>
    </form>
  );
}

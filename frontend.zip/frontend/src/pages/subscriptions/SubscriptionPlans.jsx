import React, { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Plus,
  Edit3,
  Trash2,
  Crown,
  Users2,
  Zap,
  DollarSign,
  Globe2,
  Smartphone,
  Apple,
  CheckCircle2,
  XCircle,
} from "lucide-react";

import PageHeader from "../../components/common/PageHeader";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";
import { planService, pricingService } from "../../services";
import { formatCurrency } from "../../utils";
import { cn } from "../../lib/utils";

const inputCls =
  "w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none";

const labelCls =
  "block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5";

const tierIcon = {
  free: Users2,
  premium: Zap,
  family: Crown,
  student: Users2,
  corporate: Users2,
};

export default function SubscriptionPlans() {
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState("plans");

  const [planForm, setPlanForm] = useState(null);
  const [planDelete, setPlanDelete] = useState(null);
  const [pricingForm, setPricingForm] = useState(null);
  const [pricingDelete, setPricingDelete] = useState(null);

  const { data: plans = [], isLoading: plansLoading } = useQuery({
    queryKey: ["plans"],
    queryFn: () => planService.list(),
  });

  const { data: pricingList = [], isLoading: pricingLoading } = useQuery({
    queryKey: ["pricing-master"],
    queryFn: () => pricingService.list(),
  });

  const savePlanMut = useMutation({
    mutationFn: (payload) =>
      planForm?.id
        ? planService.update(planForm.id, payload)
        : planService.create(payload),
    onSuccess: () => {
      toast.success(
        planForm?.id
          ? "Subscription plan updated"
          : "Subscription plan created"
      );
      qc.invalidateQueries({ queryKey: ["plans"] });
      setPlanForm(null);
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message ||
          "Unable to save subscription plan"
      );
    },
  });

  const deletePlanMut = useMutation({
    mutationFn: (id) => planService.delete(id),
    onSuccess: () => {
      toast.success("Subscription plan deleted");
      qc.invalidateQueries({ queryKey: ["plans"] });
      qc.invalidateQueries({ queryKey: ["pricing-master"] });
      setPlanDelete(null);
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message ||
          "Unable to delete subscription plan"
      );
    },
  });

  const savePricingMut = useMutation({
    mutationFn: (payload) =>
      pricingForm?.id
        ? pricingService.update(pricingForm.id, payload)
        : pricingService.create(payload),
    onSuccess: () => {
      toast.success(
        pricingForm?.id ? "Pricing updated" : "Pricing created"
      );
      qc.invalidateQueries({ queryKey: ["pricing-master"] });
      setPricingForm(null);
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Unable to save pricing"
      );
    },
  });

  const deletePricingMut = useMutation({
    mutationFn: (id) => pricingService.delete(id),
    onSuccess: () => {
      toast.success("Pricing deleted");
      qc.invalidateQueries({ queryKey: ["pricing-master"] });
      setPricingDelete(null);
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Unable to delete pricing"
      );
    },
  });

  const getPlanName = (entityId) => {
    const plan = plans.find((p) => Number(p.id) === Number(entityId));
    return plan?.planName || plan?.name || `Plan #${entityId}`;
  };

  const pricingByPlan = useMemo(() => {
    const grouped = {};
    pricingList.forEach((pricing) => {
      const key = pricing.entity_id ?? pricing.entityId;
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(pricing);
    });
    return grouped;
  }, [pricingList]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Subscription Management"
        subtitle="Manage subscription plans and regional pricing."
        actions={
          activeTab === "plans" ? (
            <button
              type="button"
              data-testid="plan-add-button"
              onClick={() => setPlanForm({})}
              className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Plan
            </button>
          ) : (
            <button
              type="button"
              data-testid="pricing-add-button"
              onClick={() => setPricingForm({})}
              className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Pricing
            </button>
          )
        }
      />

      {/* TABS - single wrapper only */}
      <div className="border-b border-[#27272A]">
        <div className="flex items-center gap-8">
          <button
            type="button"
            onClick={() => setActiveTab("plans")}
            className={cn(
              "relative pb-3 text-xs uppercase tracking-widest transition-colors",
              activeTab === "plans"
                ? "text-white"
                : "text-zinc-500 hover:text-white"
            )}
          >
            <span className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Subscription Plans
            </span>
            {activeTab === "plans" && (
              <span className="absolute left-0 right-0 bottom-0 h-[2px] bg-[#E50914]" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("pricing")}
            className={cn(
              "relative pb-3 text-xs uppercase tracking-widest transition-colors",
              activeTab === "pricing"
                ? "text-white"
                : "text-zinc-500 hover:text-white"
            )}
          >
            <span className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Pricing
            </span>
            {activeTab === "pricing" && (
              <span className="absolute left-0 right-0 bottom-0 h-[2px] bg-[#E50914]" />
            )}
          </button>
        </div>
      </div>

      {activeTab === "plans" && (
        <PlanTab
          plans={plans}
          loading={plansLoading}
          onEdit={setPlanForm}
          onDelete={setPlanDelete}
          pricingByPlan={pricingByPlan}
          onAddPricing={(plan) => {
            setPricingForm({
              entity_id: plan.id,
              entity_type: "SUBSCRIPTION",
            });
            setActiveTab("pricing");
          }}
        />
      )}

      {activeTab === "pricing" && (
        <PricingTab
          pricingList={pricingList}
          plans={plans}
          loading={pricingLoading}
          getPlanName={getPlanName}
          onEdit={setPricingForm}
          onDelete={setPricingDelete}
        />
      )}

      <Dialog
        open={!!planForm}
        onOpenChange={(v) => !v && setPlanForm(null)}
      >
        <DialogContent className="bg-[#141414] border-[#27272A] text-white max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-widest">
              {planForm?.id ? "Edit Subscription Plan" : "New Subscription Plan"}
            </DialogTitle>
          </DialogHeader>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);

              const payload = {
                planName: fd.get("planName"),
                planCode: fd.get("planCode"),
                planType: fd.get("planType"),
                validityDays: Number(fd.get("validityDays")) || null,
                maxDevices: Number(fd.get("maxDevices")) || null,
                maxScreens: Number(fd.get("maxScreens")) || null,
                videoQuality: fd.get("videoQuality"),
                audioQuality: fd.get("audioQuality"),
                accessAllContent: fd.get("accessAllContent") === "true",
                watchOnTvLaptop: fd.get("watchOnTvLaptop") === "true",
                adsFree: fd.get("adsFree") === "true",
                downloadAllowed: fd.get("downloadAllowed") === "true",
                featuredPlan: fd.get("featuredPlan") === "true",
                adsEnabled: fd.get("adsEnabled") === "true",
                liveChannelEnabled:
                  fd.get("liveChannelEnabled") === "true",
                description: fd.get("description"),
                status: fd.get("status"),
                displayOrder: Number(fd.get("displayOrder")) || null,
                image: fd.get("image"),
                features: String(fd.get("features") || "")
                  .split("\n")
                  .map((s) => s.trim())
                  .filter(Boolean),
              };

              savePlanMut.mutate(payload);
            }}
            className="space-y-5"
          >
            <SectionTitle>Basic Information</SectionTitle>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Plan Name">
                <input
                  name="planName"
                  required
                  defaultValue={planForm?.planName || planForm?.name || ""}
                  className={inputCls}
                />
              </Field>

              <Field label="Plan Code">
                <input
                  name="planCode"
                  required
                  defaultValue={planForm?.planCode || ""}
                  className={inputCls}
                />
              </Field>

              <Field label="Plan Type">
                <select
                  name="planType"
                  defaultValue={
                    planForm?.planType || planForm?.tier || "PREMIUM"
                  }
                  className={inputCls}
                >
                  <option value="FREE">Free</option>
                  <option value="PREMIUM">Premium</option>
                  <option value="FAMILY">Family</option>
                  <option value="STUDENT">Student</option>
                  <option value="CORPORATE">Corporate</option>
                </select>
              </Field>

              <Field label="Validity Days">
                <input
                  name="validityDays"
                  type="number"
                  defaultValue={planForm?.validityDays ?? 30}
                  className={inputCls}
                />
              </Field>

              <Field label="Max Devices">
                <input
                  name="maxDevices"
                  type="number"
                  defaultValue={planForm?.maxDevices ?? 1}
                  className={inputCls}
                />
              </Field>

              <Field label="Max Screens">
                <input
                  name="maxScreens"
                  type="number"
                  defaultValue={planForm?.maxScreens ?? 1}
                  className={inputCls}
                />
              </Field>

              <Field label="Video Quality">
                <select
                  name="videoQuality"
                  defaultValue={planForm?.videoQuality || "1080p"}
                  className={inputCls}
                >
                  <option value="4K">4K</option>
                  <option value="1080p">1080p</option>
                  <option value="720p">720p</option>
                  <option value="480p">480p</option>
                </select>
              </Field>

              <Field label="Audio Quality">
                <input
                  name="audioQuality"
                  defaultValue={planForm?.audioQuality || "Stereo"}
                  className={inputCls}
                />
              </Field>
            </div>

            <SectionTitle>Plan Features</SectionTitle>

            <div className="grid grid-cols-2 gap-3">
              {[
                ["accessAllContent", "Access All Content", true],
                ["watchOnTvLaptop", "Watch on TV / Laptop", true],
                ["adsFree", "Ads Free", true],
                ["downloadAllowed", "Download Allowed", true],
                ["featuredPlan", "Featured Plan", false],
                ["adsEnabled", "Ads Enabled", false],
                ["liveChannelEnabled", "Live Channels", false],
              ].map(([name, title, defaultValue]) => (
                <label
                  key={name}
                  className="flex items-center justify-between bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-3"
                >
                  <span className="text-sm text-zinc-300">{title}</span>
                  <input
                    type="checkbox"
                    name={name}
                    value="true"
                    defaultChecked={planForm?.[name] ?? defaultValue}
                    className="accent-[#E50914]"
                  />
                </label>
              ))}
            </div>

            <SectionTitle>Additional Information</SectionTitle>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Status">
                <select
                  name="status"
                  defaultValue={planForm?.status || "Active"}
                  className={inputCls}
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </Field>

              <Field label="Display Order">
                <input
                  name="displayOrder"
                  type="number"
                  defaultValue={planForm?.displayOrder ?? 1}
                  className={inputCls}
                />
              </Field>

              <div className="col-span-2">
                <Field label="Image URL">
                  <input
                    name="image"
                    defaultValue={planForm?.image || ""}
                    className={inputCls}
                  />
                </Field>
              </div>

              <div className="col-span-2">
                <Field label="Description">
                  <textarea
                    name="description"
                    rows={3}
                    defaultValue={planForm?.description || ""}
                    className={`${inputCls} resize-none`}
                  />
                </Field>
              </div>

              <div className="col-span-2">
                <Field label="Features - One per line">
                  <textarea
                    name="features"
                    rows={5}
                    defaultValue={(planForm?.features || []).join("\n")}
                    className={`${inputCls} resize-none`}
                  />
                </Field>
              </div>
            </div>

            <DialogFooter>
              <button
                type="button"
                onClick={() => setPlanForm(null)}
                className="h-9 px-4 border border-[#27272A] rounded-sm text-xs uppercase tracking-widest text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savePlanMut.isPending}
                className="h-9 px-4 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white"
              >
                {savePlanMut.isPending ? "Saving..." : "Save Plan"}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!pricingForm}
        onOpenChange={(v) => !v && setPricingForm(null)}
      >
        <DialogContent className="bg-[#141414] border-[#27272A] text-white max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-widest">
              {pricingForm?.id ? "Edit Pricing" : "Add Pricing"}
            </DialogTitle>
          </DialogHeader>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);

              const payload = {
                entityId: Number(fd.get("entityId")),
                entityType: "SUBSCRIPTION",
                amount: Number(fd.get("amount")),
                discountedAmount: fd.get("discountedAmount")
                  ? Number(fd.get("discountedAmount"))
                  : null,
                countryIsoCode: String(
                  fd.get("countryIsoCode") || ""
                ).toUpperCase(),
                currencyCode: String(
                  fd.get("currencyCode") || ""
                ).toUpperCase(),
                androidProductId: fd.get("androidProductId") || null,
                iosProductId: fd.get("iosProductId") || null,
                iosSubscriptionGroupId:
                  fd.get("iosSubscriptionGroupId") || null,
                taxPercentage: fd.get("taxPercentage")
                  ? Number(fd.get("taxPercentage"))
                  : null,
                priceName: fd.get("priceName") || null,
                inAppPurchaseAmount: fd.get("inAppPurchaseAmount")
                  ? Number(fd.get("inAppPurchaseAmount"))
                  : null,
               active:
                fd.get("isActive") === "true",
                effectiveFrom: fd.get("effectiveFrom") || null,
                effectiveTo: fd.get("effectiveTo") || null,
              };

              savePricingMut.mutate(payload);
            }}
            className="space-y-5"
          >
            <SectionTitle>Subscription</SectionTitle>

            <Field label="Subscription Plan">
              <select
                name="entityId"
                required
                defaultValue={
                  pricingForm?.entityId ??
                  pricingForm?.entity_id ??
                  ""
                }
                className={inputCls}
              >
                <option value="">Select Subscription Plan</option>
                {plans.map((plan) => (
                  <option key={plan.id} value={plan.id}>
                    {plan.planName || plan.name} (
                    {plan.planCode || plan.plan_code})
                  </option>
                ))}
              </select>
            </Field>

            <SectionTitle>Region & Currency</SectionTitle>

            <div className="grid grid-cols-3 gap-3">
              <Field label="Country">
                <input
                  name="countryIsoCode"
                  required
                  maxLength={2}
                  defaultValue={
                    pricingForm?.countryIsoCode ||
                    pricingForm?.country_iso_code ||
                    "IN"
                  }
                  className={`${inputCls} uppercase`}
                />
              </Field>

              <Field label="Currency">
                <input
                  name="currencyCode"
                  required
                  maxLength={3}
                  defaultValue={
                    pricingForm?.currencyCode ||
                    pricingForm?.currency_code ||
                    "INR"
                  }
                  className={`${inputCls} uppercase`}
                />
              </Field>

              <Field label="Price Name">
                <input
                  name="priceName"
                  defaultValue={
                    pricingForm?.priceName ||
                    pricingForm?.price_name ||
                    ""
                  }
                  placeholder="India Monthly"
                  className={inputCls}
                />
              </Field>
            </div>

            <SectionTitle>Price</SectionTitle>

            <div className="grid grid-cols-3 gap-3">
              <Field label="Amount">
                <input
                  name="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  defaultValue={pricingForm?.amount ?? 0}
                  className={inputCls}
                />
              </Field>

              <Field label="Discounted Amount">
                <input
                  name="discountedAmount"
                  type="number"
                  step="0.01"
                  min="0"
                  defaultValue={
                    pricingForm?.discountedAmount ??
                    pricingForm?.discounted_amount ??
                    ""
                  }
                  className={inputCls}
                />
              </Field>

              <Field label="Tax %">
                <input
                  name="taxPercentage"
                  type="number"
                  step="0.01"
                  min="0"
                  defaultValue={
                    pricingForm?.taxPercentage ??
                    pricingForm?.tax_percentage ??
                    ""
                  }
                  className={inputCls}
                />
              </Field>
            </div>

            <SectionTitle>Mobile App Products</SectionTitle>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Android Product ID">
                <div className="relative">
                  <Smartphone className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    name="androidProductId"
                    defaultValue={
                      pricingForm?.androidProductId ||
                      pricingForm?.android_product_id ||
                      ""
                    }
                    className={`${inputCls} pl-9`}
                  />
                </div>
              </Field>

              <Field label="iOS Product ID">
                <div className="relative">
                  <Apple className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                  <input
                    name="iosProductId"
                    defaultValue={
                      pricingForm?.iosProductId ||
                      pricingForm?.ios_product_id ||
                      ""
                    }
                    className={`${inputCls} pl-9`}
                  />
                </div>
              </Field>

              <Field label="iOS Subscription Group ID">
                <input
                  name="iosSubscriptionGroupId"
                  defaultValue={
                    pricingForm?.iosSubscriptionGroupId ||
                    pricingForm?.ios_subscription_group_id ||
                    ""
                  }
                  className={inputCls}
                />
              </Field>

              <Field label="IAP Amount">
                <input
                  name="inAppPurchaseAmount"
                  type="number"
                  defaultValue={
                    pricingForm?.inAppPurchaseAmount ??
                    pricingForm?.in_app_purchase_amount ??
                    ""
                  }
                  className={inputCls}
                />
              </Field>
            </div>

            <SectionTitle>Effective Period</SectionTitle>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Effective From">
                <input
                  name="effectiveFrom"
                  type="datetime-local"
                  defaultValue={
                    pricingForm?.effectiveFrom ||
                    pricingForm?.effective_from ||
                    ""
                  }
                  className={inputCls}
                />
              </Field>

              <Field label="Effective To">
                <input
                  name="effectiveTo"
                  type="datetime-local"
                  defaultValue={
                    pricingForm?.effectiveTo ||
                    pricingForm?.effective_to ||
                    ""
                  }
                  className={inputCls}
                />
              </Field>
            </div>

            <label className="flex items-center justify-between bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-sm text-zinc-300">
                  Active Pricing
                </span>
              </div>
              <input
                type="checkbox"
                name="isActive"
                value="true"
                defaultChecked={
                  pricingForm?.isActive ??
                  pricingForm?.is_active ??
                  true
                }
                className="accent-[#E50914]"
              />
            </label>

            <DialogFooter>
              <button
                type="button"
                onClick={() => setPricingForm(null)}
                className="h-9 px-4 border border-[#27272A] rounded-sm text-xs uppercase tracking-widest text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savePricingMut.isPending}
                className="h-9 px-4 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white"
              >
                {savePricingMut.isPending
                  ? "Saving..."
                  : "Save Pricing"}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!planDelete}
        onOpenChange={(v) => !v && setPlanDelete(null)}
        title={`Delete "${planDelete?.planName || planDelete?.name || ""}"?`}
        onConfirm={() =>
          planDelete && deletePlanMut.mutate(planDelete.id)
        }
        confirmText="Delete"
      />

      <ConfirmDialog
        open={!!pricingDelete}
        onOpenChange={(v) => !v && setPricingDelete(null)}
        title={`Delete pricing "${pricingDelete?.priceName || pricingDelete?.price_name || ""}"?`}
        onConfirm={() =>
          pricingDelete && deletePricingMut.mutate(pricingDelete.id)
        }
        confirmText="Delete"
      />
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div className="text-[10px] uppercase tracking-[0.2em] text-[#E50914] mb-3">
      {children}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className={labelCls}>{label}</label>
      {children}
    </div>
  );
}

function PlanTab({
  plans,
  loading,
  onEdit,
  onDelete,
  pricingByPlan,
  onAddPricing,
}) {
  if (loading) {
    return (
      <div className="text-center py-20 text-zinc-500 uppercase tracking-widest text-xs">
        Loading plans...
      </div>
    );
  }

  if (!plans.length) {
    return (
      <div className="border border-dashed border-[#27272A] rounded-sm py-20 text-center">
        <Crown className="w-10 h-10 mx-auto mb-4 text-zinc-600" />
        <div className="text-white mb-2">No subscription plans</div>
        <div className="text-sm text-zinc-500">
          Create your first subscription plan.
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
      {plans.map((p) => {
        const tier = String(
          p.planType || p.tier || "premium"
        ).toLowerCase();

        const Icon = tierIcon[tier] || Zap;
        const featured =
          p.featuredPlan ?? p.featured ?? tier === "family";
        const planPricing = pricingByPlan[p.id] || [];

        return (
          <div
            key={p.id}
            data-testid={`plan-card-${p.id}`}
            className={cn(
              "relative bg-[#141414] border rounded-sm p-6 hover:border-[#3F3F46] transition-colors",
              featured ? "border-[#E50914]" : "border-[#27272A]"
            )}
          >
            {featured && (
              <div className="absolute -top-2.5 left-6 bg-[#E50914] text-white text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-sm">
                Most Popular
              </div>
            )}

            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-1">
                  {p.planType || p.tier || "Premium"}
                  {p.validityDays ? ` · ${p.validityDays} DAYS` : ""}
                </div>

                <div className="font-display uppercase text-2xl text-white tracking-widest">
                  {p.planName || p.name}
                </div>

                <div className="text-[10px] text-zinc-600 mt-1 font-mono">
                  {p.planCode || p.plan_code}
                </div>
              </div>

              <div className="w-10 h-10 flex items-center justify-center border border-[#27272A] rounded-sm">
                <Icon className="w-5 h-5 text-[#E50914]" />
              </div>
            </div>

            <div className="bg-[#0A0A0A] border border-[#27272A] rounded-sm p-3 mb-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase tracking-widest text-zinc-500">
                  Pricing
                </span>
                <span className="text-[10px] text-zinc-500">
                  {planPricing.length} region(s)
                </span>
              </div>

              {planPricing.length === 0 ? (
                <div className="flex items-center gap-2 text-xs text-zinc-600">
                  <XCircle className="w-3.5 h-3.5" />
                  No pricing configured
                </div>
              ) : (
                <div className="space-y-2">
                  {planPricing.slice(0, 3).map((price) => {
                    const currency =
                      price.currencyCode ||
                      price.currency_code ||
                      "";

                    const amount =
                      price.discountedAmount ??
                      price.discounted_amount ??
                      price.amount;

                    const country =
                      price.countryIsoCode ||
                      price.country_iso_code ||
                      "";

                    return (
                      <div
                        key={price.id}
                        className="flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2">
                          <Globe2 className="w-3.5 h-3.5 text-zinc-500" />
                          <span className="text-xs text-zinc-400">
                            {country}
                          </span>
                        </div>

                        <span className="text-sm text-white font-mono">
                          {formatCurrency(amount, currency)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="border-t border-[#27272A] pt-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <Detail label="Devices" value={p.maxDevices ?? "-"} />
                <Detail label="Screens" value={p.maxScreens ?? "-"} />
                <Detail
                  label="Quality"
                  value={p.videoQuality || p.max_quality || "-"}
                />
                <div className="flex justify-between">
                  <span className="text-zinc-500">Live TV</span>
                  <span
                    className={
                      p.liveChannelEnabled
                        ? "text-emerald-400"
                        : "text-zinc-600"
                    }
                  >
                    {p.liveChannelEnabled ? "YES" : "NO"}
                  </span>
                </div>
              </div>

              {(p.features || []).slice(0, 4).map((f, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 mt-2 text-sm text-zinc-300"
                >
                  <span className="w-1 h-1 bg-[#E50914] rounded-full" />
                  {f}
                </div>
              ))}
            </div>

            <div className="flex gap-2 mt-6">
              <button
                type="button"
                onClick={() => onEdit(p)}
                className="flex-1 h-9 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-xs uppercase tracking-widest text-white flex items-center justify-center gap-2"
              >
                <Edit3 className="w-3.5 h-3.5" />
                Edit
              </button>

              <button
                type="button"
                onClick={() => onAddPricing(p)}
                className="h-9 px-3 border border-[#27272A] hover:border-[#E50914] rounded-sm text-xs uppercase tracking-widest text-white flex items-center justify-center gap-2"
              >
                <DollarSign className="w-3.5 h-3.5" />
                Pricing
              </button>

              <button
                type="button"
                onClick={() => onDelete(p)}
                className="w-9 h-9 border border-[#27272A] hover:border-red-500 rounded-sm text-red-400 flex items-center justify-center"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Detail({ label, value }) {
  return (
    <div className="flex justify-between">
      <span className="text-zinc-500">{label}</span>
      <span className="text-white font-mono">{value}</span>
    </div>
  );
}

function PricingTab({
  pricingList,
  loading,
  getPlanName,
  onEdit,
  onDelete,
}) {
  if (loading) {
    return (
      <div className="text-center py-20 text-zinc-500 uppercase tracking-widest text-xs">
        Loading pricing...
      </div>
    );
  }

  return (
    <div className="bg-[#141414] border border-[#27272A] rounded-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-[#27272A] flex items-center justify-between">
        <div>
          <div className="text-white font-display uppercase tracking-widest">
            Pricing Master
          </div>
          <div className="text-xs text-zinc-500 mt-1">
            Manage country, currency and platform-specific pricing.
          </div>
        </div>

        <div className="text-xs text-zinc-500">
          {pricingList.length} pricing records
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#27272A] text-[10px] uppercase tracking-widest text-zinc-500">
              <th className="text-left px-5 py-3">Subscription</th>
              <th className="text-left px-5 py-3">Region</th>
              <th className="text-left px-5 py-3">Currency</th>
              <th className="text-right px-5 py-3">Amount</th>
              <th className="text-right px-5 py-3">Discount</th>
              <th className="text-left px-5 py-3">Android</th>
              <th className="text-left px-5 py-3">iOS</th>
              <th className="text-center px-5 py-3">Status</th>
              <th className="text-right px-5 py-3">Actions</th>
            </tr>
          </thead>

          <tbody>
            {pricingList.length === 0 ? (
              <tr>
                <td
                  colSpan={9}
                  className="text-center py-16 text-zinc-600 text-sm"
                >
                  No pricing configured.
                </td>
              </tr>
            ) : (
              pricingList.map((pricing) => {
                const entityId =
                  pricing.entityId ?? pricing.entity_id;

                const country =
                  pricing.countryIsoCode ||
                  pricing.country_iso_code ||
                  "";

                const currency =
                  pricing.currencyCode ||
                  pricing.currency_code ||
                  "";

                const amount = pricing.amount ?? 0;

                const discounted =
                  pricing.discountedAmount ??
                  pricing.discounted_amount;

                const discount =
                  discounted != null && Number(amount) > 0
                    ? Math.round(
                        ((Number(amount) - Number(discounted)) /
                          Number(amount)) *
                          100
                      )
                    : null;

                return (
                  <tr
                    key={pricing.id}
                    className="border-b border-[#1F1F1F] hover:bg-[#181818]"
                  >
                    <td className="px-5 py-4">
                      <div className="text-sm text-white">
                        {getPlanName(entityId)}
                      </div>
                      <div className="text-[10px] text-zinc-600 font-mono mt-1">
                        ID: {entityId}
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2 text-sm text-zinc-300">
                        <Globe2 className="w-4 h-4 text-zinc-500" />
                        {country}
                      </div>
                    </td>

                    <td className="px-5 py-4 text-sm text-zinc-300 font-mono">
                      {currency}
                    </td>

                    <td className="px-5 py-4 text-right">
                      <div className="text-sm text-white font-mono">
                        {formatCurrency(amount, currency)}
                      </div>

                      {discounted != null && (
                        <div className="text-xs text-emerald-400 font-mono mt-1">
                          {formatCurrency(discounted, currency)}
                        </div>
                      )}
                    </td>

                    <td className="px-5 py-4 text-right">
                      {discount != null ? (
                        <span className="text-xs text-emerald-400">
                          {discount}%
                        </span>
                      ) : (
                        <span className="text-xs text-zinc-600">—</span>
                      )}
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2 text-xs text-zinc-400">
                        <Smartphone className="w-3.5 h-3.5" />
                        <span className="max-w-[150px] truncate">
                          {pricing.androidProductId ||
                            pricing.android_product_id ||
                            "—"}
                        </span>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2 text-xs text-zinc-400">
                        <Apple className="w-3.5 h-3.5" />
                        <span className="max-w-[150px] truncate">
                          {pricing.iosProductId ||
                            pricing.ios_product_id ||
                            "—"}
                        </span>
                      </div>
                    </td>

                    <td className="px-5 py-4 text-center">
                      {pricing.active ?? pricing.active ? (
                        <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-emerald-400">
                          <CheckCircle2 className="w-3 h-3" />
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-zinc-600">
                          <XCircle className="w-3 h-3" />
                          Inactive
                        </span>
                      )}
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => onEdit(pricing)}
                          className="w-8 h-8 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-white flex items-center justify-center"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onDelete(pricing)}
                          className="w-8 h-8 border border-[#27272A] hover:border-red-500 rounded-sm text-red-400 flex items-center justify-center"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

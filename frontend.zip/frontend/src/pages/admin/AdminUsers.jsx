import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Edit3, Trash2 } from "lucide-react";
import PageHeader from "../../components/common/PageHeader";
import StatusBadge from "../../components/common/StatusBadge";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { adminService } from "../../services";
import { formatDate, initials } from "../../utils";

const inputCls = "w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none";

export default function AdminUsers() {
  const qc = useQueryClient();
  const { data: users = [] } = useQuery({ queryKey: ["admin-users"], queryFn: () => adminService.listUsers() });
  const { data: roles = [] } = useQuery({ queryKey: ["admin-roles"], queryFn: () => adminService.listRoles() });
  const [form, setForm] = useState(null);
  const [del, setDel] = useState(null);
console.log("ADMIN USERS RESPONSE:", users);
  const saveMut = useMutation({
    mutationFn: (b) => form?.id ? adminService.updateUser(form.id, b) : adminService.createUser(b),
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["admin-users"] }); setForm(null); },
    onError: (e) => toast.error("Failed", { description: e?.detail }),
  });
  const delMut = useMutation({
    mutationFn: (id) => adminService.deleteUser(id),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-users"] }); setDel(null); },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Admin Users"
        subtitle="Manage staff accounts with fine-grained roles and status."
        actions={
          <button data-testid="admin-add-button" onClick={() => setForm({})} className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
            <Plus className="w-3.5 h-3.5" /> Add Admin
          </button>
        }
      />

      <div className="border border-[#27272A] rounded-sm overflow-hidden bg-[#141414]">
        <table className="w-full text-sm">
          <thead className="bg-[#0A0A0A] text-[10px] uppercase tracking-[0.2em] text-zinc-500">
            <tr>
              <th className="p-3 text-left">Admin</th>
              <th className="p-3 text-left">Email</th>
              <th className="p-3 text-left">Role</th>
              <th className="p-3 text-left">Status</th>
              <th className="p-3 text-left">Created</th>
              <th className="p-3 text-right">Actions</th>
            </tr>
          </thead>
         <tbody>
{
users.map((u)=>(
<tr key={u.id} className="border-t border-[#27272A] hover:bg-[#1E1E1E]">

<td className="p-3">
<div className="flex items-center gap-3">

<div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#E50914] to-[#7a0208] flex items-center justify-center text-[10px] font-bold text-white">
{
initials(u.fullName || u.username)
}
</div>

<div className="text-white">
{u.fullName || u.username}
</div>

</div>
</td>


<td className="p-3 text-zinc-400 text-xs">
{u.email}
</td>


<td className="p-3">

<span className="px-2 py-0.5 rounded-sm text-[10px] uppercase tracking-widest bg-[#E50914]/10 border border-[#E50914]/30 text-[#E50914] font-semibold">

{u.userType}

</span>

</td>


<td className="p-3">

<StatusBadge 
status={u.active ? "active" : "inactive"}
/>

</td>


<td className="p-3 text-zinc-400 text-xs">
-
</td>


<td className="p-3 text-right">

<div className="inline-flex gap-1">

<button 
onClick={()=>setForm(u)}
className="w-7 h-7 flex items-center justify-center border border-[#27272A]"
>
<Edit3 className="w-3.5 h-3.5"/>
</button>


<button
onClick={()=>setDel(u)}
className="w-7 h-7 flex items-center justify-center border border-[#27272A]"
>
<Trash2 className="w-3.5 h-3.5"/>
</button>


</div>

</td>


</tr>
))
}
</tbody>
        </table>
      </div>

      <Dialog open={!!form} onOpenChange={(v) => !v && setForm(null)}>
        <DialogContent className="bg-[#141414] border-[#27272A] text-white max-w-md">
          <DialogHeader><DialogTitle className="font-display uppercase tracking-widest">{form?.id ? "Edit Admin" : "New Admin"}</DialogTitle></DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            const b = { name: fd.get("name"), email: fd.get("email"), role: fd.get("role"), status: fd.get("status") };
            const pwd = fd.get("password");
            if (pwd) b.password = pwd;
            saveMut.mutate(b);
          }} className="space-y-4">
            <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Name</label><input data-testid="admin-form-name" name="name" defaultValue={form?.name} required className={inputCls} /></div>
            <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Email</label><input data-testid="admin-form-email" name="email" type="email" defaultValue={form?.email} required className={inputCls} /></div>
            <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Role</label>
              <select name="role" defaultValue={form?.role || "content-manager"} className={inputCls}>
                {roles.map((r) => <option key={r.id} value={r.name.toLowerCase().replace(/\s+/g, "-")}>{r.name}</option>)}
              </select>
            </div>
            <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Status</label>
              <select name="status" defaultValue={form?.status || "active"} className={inputCls}>
                <option value="active">Active</option><option value="inactive">Inactive</option>
              </select>
            </div>
            <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Password {form?.id && <span className="text-zinc-600">(leave blank to keep)</span>}</label><input name="password" type="password" placeholder={form?.id ? "••••••••" : "Admin@123"} className={inputCls} /></div>
            <DialogFooter>
              <button type="button" onClick={() => setForm(null)} className="h-9 px-4 border border-[#27272A] rounded-sm text-xs uppercase tracking-widest text-white hover:border-[#3F3F46]">Cancel</button>
              <button data-testid="admin-form-save" type="submit" className="h-9 px-4 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white">Save</button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!del} onOpenChange={(v) => !v && setDel(null)} title={`Delete "${del?.name}"?`} onConfirm={() => del && delMut.mutate(del.id)} confirmText="Delete" />
    </div>
  );
}

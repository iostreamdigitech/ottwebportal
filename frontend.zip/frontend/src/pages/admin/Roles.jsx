import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Edit3, Trash2, ShieldCheck } from "lucide-react";
import PageHeader from "../../components/common/PageHeader";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { adminService } from "../../services";

const inputCls = "w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none";

export default function Roles() {
  const qc = useQueryClient();
  const { data: roles = [] } = useQuery({ queryKey: ["admin-roles"], queryFn: () => adminService.listRoles() });
  const { data: permissions = [] } = useQuery({ queryKey: ["admin-permissions"], queryFn: () => adminService.listPermissions() });
  const [form, setForm] = useState(null);
  const [del, setDel] = useState(null);
  const [selectedPerms, setSelectedPerms] = useState([]);

  const openForm = (r) => {
    setForm(r || {});
    setSelectedPerms(r?.permissions || []);
  };

  const togglePerm = (key) => {
    setSelectedPerms((prev) => prev.includes(key) ? prev.filter((p) => p !== key) : [...prev, key]);
  };

  const saveMut = useMutation({
    mutationFn: (b) => form?.id ? adminService.updateRole(form.id, b) : adminService.createRole(b),
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["admin-roles"] }); setForm(null); },
  });
  const delMut = useMutation({
    mutationFn: (id) => adminService.deleteRole(id),
    onSuccess: () => { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["admin-roles"] }); setDel(null); },
  });

  const grouped = permissions.reduce((acc, p) => { (acc[p.group] = acc[p.group] || []).push(p); return acc; }, {});

  return (
    <div className="space-y-6">
      <PageHeader
        title="Roles & Permissions"
        subtitle="Design least-privilege access for every team from Content Ops to Finance."
        actions={
          <button data-testid="role-add-button" onClick={() => openForm(null)} className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
            <Plus className="w-3.5 h-3.5" /> Add Role
          </button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {roles.map((r) => (
          <div key={r.id} className="bg-[#141414] border border-[#27272A] rounded-sm p-5 hover:border-[#3F3F46] transition-colors" data-testid={`role-card-${r.id}`}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="font-display uppercase text-lg text-white tracking-widest">{r.name}</div>
                <p className="text-xs text-zinc-500 mt-1 line-clamp-2">{r.description}</p>
              </div>
              <div className="w-9 h-9 border border-[#27272A] rounded-sm flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-[#E50914]" />
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {(r.permissions || []).slice(0, 6).map((p) => (
                <span key={p} className="text-[10px] uppercase tracking-widest bg-[#0A0A0A] border border-[#27272A] px-2 py-0.5 rounded-sm text-zinc-400">{p}</span>
              ))}
              {(r.permissions || []).length > 6 && <span className="text-[10px] text-zinc-500">+{r.permissions.length - 6}</span>}
            </div>
            <div className="flex gap-2 mt-4 pt-4 border-t border-[#27272A]">
              <button data-testid={`role-edit-${r.id}`} onClick={() => openForm(r)} className="flex-1 h-8 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-[10px] uppercase tracking-widest text-white flex items-center justify-center gap-1.5">
                <Edit3 className="w-3 h-3" /> Edit
              </button>
              <button data-testid={`role-delete-${r.id}`} onClick={() => setDel(r)} className="w-8 h-8 border border-[#27272A] hover:border-red-500 rounded-sm text-red-400 flex items-center justify-center">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={!!form} onOpenChange={(v) => !v && setForm(null)}>
        <DialogContent className="bg-[#141414] border-[#27272A] text-white max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="font-display uppercase tracking-widest">{form?.id ? "Edit Role" : "New Role"}</DialogTitle></DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            saveMut.mutate({ name: fd.get("name"), description: fd.get("description"), permissions: selectedPerms });
          }} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Role Name</label><input data-testid="role-form-name" name="name" defaultValue={form?.name} required className={inputCls} /></div>
              <div><label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Description</label><input name="description" defaultValue={form?.description} className={inputCls} /></div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-zinc-500 mb-2">Permissions Matrix</div>
              <div className="space-y-4">
                {Object.entries(grouped).map(([group, perms]) => (
                  <div key={group} className="border border-[#27272A] rounded-sm p-4">
                    <div className="text-xs uppercase tracking-widest text-[#E50914] font-semibold mb-3">{group}</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {perms.map((p) => (
                        <label key={p.key} className="flex items-center gap-2 cursor-pointer text-sm">
                          <input type="checkbox" checked={selectedPerms.includes(p.key)} onChange={() => togglePerm(p.key)} className="accent-[#E50914]" />
                          <span className="text-white">{p.label}</span>
                          <span className="text-[10px] text-zinc-600 font-mono ml-auto">{p.key}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <DialogFooter>
              <button type="button" onClick={() => setForm(null)} className="h-9 px-4 border border-[#27272A] rounded-sm text-xs uppercase tracking-widest text-white hover:border-[#3F3F46]">Cancel</button>
              <button data-testid="role-form-save" type="submit" className="h-9 px-4 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white">Save Role</button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!del} onOpenChange={(v) => !v && setDel(null)} title={`Delete "${del?.name}"?`} onConfirm={() => del && delMut.mutate(del.id)} confirmText="Delete" />
    </div>
  );
}

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Search, Plus, Trash2, Ban, CheckCircle2, ChevronLeft, ChevronRight, Download } from "lucide-react";
import PageHeader from "../../components/common/PageHeader";
import StatusBadge from "../../components/common/StatusBadge";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { TableSkeleton } from "../../components/common/LoadingSkeleton";
import EmptyState from "../../components/common/EmptyState";
import { userService } from "../../services";
import { formatDate, initials, formatNumber } from "../../utils";
import { cn } from "../../lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";

const PLANS = ["all", "free", "premium", "family", "student"];
const STATUSES = ["all", "active", "blocked"];

export default function UserList() {
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [plan, setPlan] = useState("all");
  const [selected, setSelected] = useState([]);
  const [confirm, setConfirm] = useState({ open: false, action: null });
  const [form, setForm] = useState(null);

  const params = { page, page_size: 12, q: q || undefined, status: status !== "all" ? status : undefined, plan: plan !== "all" ? plan : undefined };
  const { data, isLoading } = useQuery({
    queryKey: ["users", params],
    queryFn: () => userService.list(params),
    keepPreviousData: true,
  });

  console.log("Cu USERS RESPONSE:", data);

  const createMut = useMutation({
    mutationFn: (body) => (form?.id ? userService.update(form.id, body) : userService.create(body)),
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["users"] }); setForm(null); },
    onError: (e) => toast.error("Save failed", { description: e?.detail }),
  });

  const bulkMut = useMutation({
    mutationFn: ({ ids, action }) => userService.bulk(ids, action),
    onSuccess: (r) => { toast.success(`${r.affected} users updated`); qc.invalidateQueries({ queryKey: ["users"] }); setSelected([]); },
  });

  const toggleAll = () => setSelected(selected.length === (data?.items || []).length ? [] : (data?.items || []).map((u) => u.id));
  const toggleOne = (id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const performBulk = (action) => {
    if (!selected.length) return toast.error("Select at least one user");
    setConfirm({ open: true, action });
  };

  const runBulk = () => {
    bulkMut.mutate({ ids: selected, action: confirm.action });
    setConfirm({ open: false, action: null });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Customer Management"
        subtitle="Search, segment and moderate every viewer across the platform."
        actions={
          <>
            <button data-testid="user-export-button" className="h-9 px-3 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Download className="w-3.5 h-3.5" /> Export
            </button>
            <button data-testid="user-add-button" onClick={() => setForm({})} className="h-9 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Plus className="w-3.5 h-3.5" /> Add User
            </button>
          </>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            data-testid="user-search-input"
            placeholder="Search by name or email…"
            value={q}
            onChange={(e) => { setQ(e.target.value); setPage(1); }}
            className="w-full bg-[#141414] border border-[#27272A] rounded-sm pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#E50914] focus:outline-none"
          />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger data-testid="user-status-filter" className="w-[140px] bg-[#141414] border-[#27272A] text-white h-10">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-[#141414] border-[#27272A] text-white">
            {STATUSES.map((s) => <SelectItem key={s} value={s} className="focus:bg-[#1E1E1E] focus:text-white capitalize">{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={plan} onValueChange={(v) => { setPlan(v); setPage(1); }}>
          <SelectTrigger data-testid="user-plan-filter" className="w-[140px] bg-[#141414] border-[#27272A] text-white h-10">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-[#141414] border-[#27272A] text-white">
            {PLANS.map((s) => <SelectItem key={s} value={s} className="focus:bg-[#1E1E1E] focus:text-white capitalize">{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Bulk actions bar */}
      {selected.length > 0 && (
        <div className="flex items-center justify-between bg-[#1E1E1E] border border-[#27272A] rounded-sm px-4 py-3">
          <div className="text-xs uppercase tracking-widest text-zinc-400">{selected.length} selected</div>
          <div className="flex gap-2">
            <button onClick={() => performBulk("activate")} className="h-8 px-3 border border-[#27272A] hover:border-emerald-500 text-emerald-400 rounded-sm text-xs uppercase tracking-widest flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Activate
            </button>
            <button onClick={() => performBulk("block")} className="h-8 px-3 border border-[#27272A] hover:border-amber-500 text-amber-400 rounded-sm text-xs uppercase tracking-widest flex items-center gap-1.5">
              <Ban className="w-3.5 h-3.5" /> Block
            </button>
            <button data-testid="user-bulk-delete-button" onClick={() => performBulk("delete")} className="h-8 px-3 bg-[#E50914] hover:bg-[#F40612] rounded-sm text-xs uppercase tracking-widest text-white flex items-center gap-1.5">
              <Trash2 className="w-3.5 h-3.5" /> Delete
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      {isLoading ? <TableSkeleton /> : (data?.items?.length ? (
        <div className="border border-[#27272A] rounded-sm overflow-hidden bg-[#141414]">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-[#0A0A0A] text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                <tr>
                  <th className="p-3 text-left w-10">
                    <input type="checkbox" data-testid="user-select-all" checked={selected.length === data.items.length} onChange={toggleAll} className="accent-[#E50914]" />
                  </th>
                  <th className="p-3 text-left">User</th>
                  <th className="p-3 text-left">Contact</th>
                  <th className="p-3 text-left">Plan</th>
                  <th className="p-3 text-left">Status</th>
                  <th className="p-3 text-left">Watch Hours</th>
                  <th className="p-3 text-left">Devices</th>
                  <th className="p-3 text-left">Joined</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((u) => (
                  <tr key={u.id} className="border-t border-[#27272A] hover:bg-[#1E1E1E]" data-testid={`user-row-${u.id}`}>
                    <td className="p-3">
                      <input type="checkbox" checked={selected.includes(u.id)} onChange={() => toggleOne(u.id)} className="accent-[#E50914]" />
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#E50914] to-[#7a0208] flex items-center justify-center text-[10px] font-bold text-white">
                          {initials(u.fullName || u.username)}
                        </div>
                        <div>
                          <div className="text-white font-medium">{u.fullName || u.username}</div>
                          <div className="text-[10px] text-zinc-500 uppercase tracking-widest">{u.country}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 text-zinc-400 text-xs">
                      <div>{u.email}</div>
                      <div className="text-zinc-600 font-mono">{u.phone}</div>
                    </td>
                    <td className="p-3">
                      <span className={cn(
                        "px-2 py-0.5 rounded-sm text-[10px] uppercase tracking-widest border font-semibold",
                        u.plan === "family" && "text-purple-300 bg-purple-500/10 border-purple-500/30",
                        u.plan === "premium" && "text-[#E50914] bg-[#E50914]/10 border-[#E50914]/30",
                        u.plan === "free" && "text-zinc-400 bg-zinc-500/10 border-zinc-500/30",
                        u.plan === "student" && "text-sky-300 bg-sky-500/10 border-sky-500/30",
                      )}>{u.plan}</span>
                    </td>
                    <td className="p-3"><StatusBadge status={u.status} /></td>
                    <td className="p-3 text-white font-mono text-xs">{formatNumber(u.watch_hours)}h</td>
                    <td className="p-3 text-white font-mono text-xs">{u.devices}</td>
                    <td className="p-3 text-zinc-400 text-xs">{formatDate(u.created_at)}</td>
                    <td className="p-3 text-right">
                      <button data-testid={`user-edit-${u.id}`} onClick={() => setForm(u)} className="text-xs uppercase tracking-widest text-[#E50914] hover:text-[#F40612]">Edit</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between p-4 border-t border-[#27272A]">
            <div className="text-xs text-zinc-500">Showing <span className="text-white">{data.items.length}</span> of <span className="text-white">{data.total}</span></div>
            <div className="flex items-center gap-2">
              <button data-testid="user-prev-page" onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1} className="w-8 h-8 flex items-center justify-center border border-[#27272A] rounded-sm disabled:opacity-40 hover:border-[#3F3F46]"><ChevronLeft className="w-4 h-4" /></button>
              <div className="text-xs text-zinc-400 font-mono px-2">{page} / {data.pages}</div>
              <button data-testid="user-next-page" onClick={() => setPage(Math.min(data.pages, page + 1))} disabled={page === data.pages} className="w-8 h-8 flex items-center justify-center border border-[#27272A] rounded-sm disabled:opacity-40 hover:border-[#3F3F46]"><ChevronRight className="w-4 h-4" /></button>
            </div>
          </div>
        </div>
      ) : <EmptyState title="No users found" subtitle="Adjust filters or add a new user to get started." />)}

      {/* Add/edit dialog */}
      <Dialog open={!!form} onOpenChange={(v) => !v && setForm(null)}>
        <DialogContent className="bg-[#141414] border-[#27272A] text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-widest">{form?.id ? "Edit User" : "New User"}</DialogTitle>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const body = { name: fd.get("name"), email: fd.get("email"), phone: fd.get("phone"), country: fd.get("country"), plan: fd.get("plan"), status: fd.get("status") };
              createMut.mutate(body);
            }}
            className="space-y-4"
          >
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Name</label>
                <input name="name" defaultValue={form?.name || ""} required data-testid="user-form-name" className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Email</label>
                <input name="email" defaultValue={form?.email || ""} required data-testid="user-form-email" className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Phone</label>
                <input name="phone" defaultValue={form?.phone || ""} className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Country</label>
                <input name="country" defaultValue={form?.country || "India"} className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Plan</label>
                <select name="plan" defaultValue={form?.plan || "free"} className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none">
                  {PLANS.filter((p) => p !== "all").map((p) => <option key={p} value={p} className="capitalize">{p}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1.5">Status</label>
                <select name="status" defaultValue={form?.status || "active"} className="w-full bg-[#0A0A0A] border border-[#27272A] rounded-sm px-3 py-2 text-sm text-white focus:border-[#E50914] focus:outline-none">
                  <option value="active">Active</option>
                  <option value="blocked">Blocked</option>
                </select>
              </div>
            </div>
            <DialogFooter>
              <button type="button" onClick={() => setForm(null)} className="h-9 px-4 border border-[#27272A] hover:border-[#3F3F46] rounded-sm text-xs uppercase tracking-widest">Cancel</button>
              <button data-testid="user-form-save" type="submit" disabled={createMut.isPending} className="h-9 px-4 bg-[#E50914] hover:bg-[#F40612] text-white rounded-sm text-xs uppercase tracking-widest">
                {createMut.isPending ? "Saving…" : "Save"}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={confirm.open}
        onOpenChange={(v) => setConfirm({ ...confirm, open: v })}
        title={`${confirm.action} ${selected.length} users?`}
        description={`This will ${confirm.action} the selected users${confirm.action === "delete" ? " permanently" : ""}.`}
        onConfirm={runBulk}
        confirmText={confirm.action}
        destructive={confirm.action === "delete" || confirm.action === "block"}
      />
    </div>
  );
}

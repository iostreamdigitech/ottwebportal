import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronLeft, Zap } from "lucide-react";
import { MENU } from "../../constants/menu";
import { LAYOUT } from "../../constants/testIds";
import { useUiStore } from "../../store/uiStore";
import { cn } from "../../lib/utils";

export default function Sidebar() {
  const { sidebarCollapsed, toggleSidebar } = useUiStore();
  const loc = useLocation();

  return (
    <aside
      data-testid={LAYOUT.sidebar}
      className={cn(
        "fixed top-0 left-0 h-screen bg-[#0A0A0A] border-r border-[#27272A] z-40 transition-[width] duration-200 flex flex-col",
        sidebarCollapsed ? "w-[72px]" : "w-[260px]"
      )}
    >
      {/* Brand */}
      <div className="h-16 border-b border-[#27272A] flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="w-9 h-9 shrink-0 flex items-center justify-center bg-[#E50914] rounded-sm">
            <Zap className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <div className="font-display text-lg uppercase tracking-widest leading-none text-white truncate">
                CineStream
              </div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mt-0.5">
                Admin CMS
              </div>
            </div>
          )}
        </div>
        <button
          data-testid={LAYOUT.sidebarToggle}
          onClick={toggleSidebar}
          className="w-7 h-7 flex items-center justify-center hover:bg-[#1E1E1E] rounded-sm text-zinc-400 hover:text-white transition-colors"
        >
          <ChevronLeft className={cn("w-4 h-4 transition-transform", sidebarCollapsed && "rotate-180")} />
        </button>
      </div>

      {/* Menu */}
      <div className="flex-1 overflow-y-auto py-4">
        {MENU.map((group) => (
          <div key={group.section} className="mb-4">
            {!sidebarCollapsed && (
              <div className="px-6 mb-2 text-[10px] uppercase tracking-[0.2em] text-zinc-600 font-medium">
                {group.section}
              </div>
            )}
            <nav className="flex flex-col gap-0.5 px-2">
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = loc.pathname === item.to || loc.pathname.startsWith(item.to + "/");
                return (
                  <NavLink
                    key={item.key}
                    to={item.to}
                    data-testid={item.testid}
                    className={cn(
                      "relative flex items-center gap-3 px-4 py-2.5 text-sm rounded-sm transition-colors",
                      active ? "text-white bg-[#1E1E1E]" : "text-zinc-400 hover:text-white hover:bg-[#141414]"
                    )}
                  >
                    {active && (
                      <motion.span
                        layoutId="sidebar-active"
                        className="absolute left-0 top-1 bottom-1 w-[3px] bg-[#E50914] rounded-r"
                      />
                    )}
                    <Icon className="w-4 h-4 shrink-0" strokeWidth={2} />
                    {!sidebarCollapsed && (
                      <span className="truncate font-medium">{item.label}</span>
                    )}
                  </NavLink>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Footer */}
      {!sidebarCollapsed && (
        <div className="border-t border-[#27272A] p-4 text-[10px] uppercase tracking-widest text-zinc-600">
          v1.0.0 · Enterprise Edition
        </div>
      )}
    </aside>
  );
}

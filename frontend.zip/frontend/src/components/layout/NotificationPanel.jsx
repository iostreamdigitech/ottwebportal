import React from "react";
import { Popover, PopoverContent, PopoverTrigger } from "../../components/ui/popover";
import { useQuery } from "@tanstack/react-query";
import { notificationService } from "../../services";
import { CheckCircle2, AlertTriangle, XCircle, Info } from "lucide-react";
import { formatDate } from "../../utils";

const iconMap = {
  success: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
  warning: <AlertTriangle className="w-4 h-4 text-amber-500" />,
  error: <XCircle className="w-4 h-4 text-red-500" />,
  info: <Info className="w-4 h-4 text-sky-500" />,
};

export default function NotificationPanel({ children }) {
  const { data = [] } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => notificationService.list(),
  });
  return (
    <Popover>
      <PopoverTrigger asChild>{children}</PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-[380px] p-0 bg-[#141414] border-[#27272A] text-white"
      >
        <div className="p-4 border-b border-[#27272A] flex items-center justify-between">
          <div>
            <div className="font-display uppercase tracking-widest text-sm">Notifications</div>
            <div className="text-[11px] text-zinc-500 mt-0.5">{data.length} recent activity</div>
          </div>
          <button className="text-[10px] uppercase tracking-widest text-zinc-500 hover:text-white">Mark all read</button>
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          {data.map((n) => (
            <div key={n.id} className="p-4 border-b border-[#27272A] hover:bg-[#1E1E1E] transition-colors flex gap-3">
              <div className="mt-0.5">{iconMap[n.type] || iconMap.info}</div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-white truncate">{n.title}</div>
                <div className="text-xs text-zinc-400 mt-0.5 line-clamp-2">{n.body}</div>
                <div className="text-[10px] text-zinc-600 uppercase tracking-widest mt-1.5">{formatDate(n.created_at)}</div>
              </div>
            </div>
          ))}
          {!data.length && (
            <div className="p-8 text-center text-sm text-zinc-500">No notifications yet.</div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

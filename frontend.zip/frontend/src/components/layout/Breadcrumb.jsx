import React from "react";
import { Link, useLocation } from "react-router-dom";
import { ChevronRight, Home } from "lucide-react";

export default function Breadcrumb() {
  const loc = useLocation();
  const parts = loc.pathname.split("/").filter(Boolean);
  return (
    <nav className="flex items-center gap-1.5 text-[11px] uppercase tracking-widest text-zinc-500">
      <Link to="/dashboard" className="hover:text-white flex items-center gap-1">
        <Home className="w-3 h-3" /> Home
      </Link>
      {parts.map((p, i) => {
        const to = "/" + parts.slice(0, i + 1).join("/");
        const isLast = i === parts.length - 1;
        return (
          <React.Fragment key={to}>
            <ChevronRight className="w-3 h-3" />
            {isLast ? (
              <span className="text-white">{p.replace(/-/g, " ")}</span>
            ) : (
              <Link to={to} className="hover:text-white">{p.replace(/-/g, " ")}</Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}

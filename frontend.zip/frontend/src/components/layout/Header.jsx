import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Bell, Sun, Moon, LogOut, User, KeyRound, Command } from "lucide-react";
import { LAYOUT, AUTH } from "../../constants/testIds";
import { useAuthStore } from "../../store/authStore";
import { useUiStore } from "../../store/uiStore";
import { initials } from "../../utils";
import { cn } from "../../lib/utils";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel,
} from "../../components/ui/dropdown-menu";
import NotificationPanel from "./NotificationPanel";

export default function Header() {
  const nav = useNavigate();
  const { user, reset } = useAuthStore();
  const { toggleNotifications } = useUiStore();
  const [isLight, setIsLight] = useState(() => !document.documentElement.classList.contains("dark"));

  useEffect(() => {
    const root = document.documentElement;
    if (isLight) {
      root.classList.remove("dark");
      root.classList.add("light");
    } else {
      root.classList.add("dark");
      root.classList.remove("light");
    }
  }, [isLight]);

  const toggleTheme = () => setIsLight((v) => !v);

  const logout = () => {
    localStorage.removeItem("ott_token");
    reset();
    nav("/login");
  };

  return (
    <header className="sticky top-0 z-30 h-16 border-b border-[#27272A] bg-[#0A0A0A]/95 backdrop-blur-md flex items-center px-6 gap-4">
      {/* Global search */}
      <div className="flex-1 max-w-xl relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          data-testid={LAYOUT.headerSearch}
          placeholder="Search movies, users, orders…"
          className="w-full bg-[#141414] border border-[#27272A] rounded-sm pl-10 pr-14 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-[#E50914] focus:outline-none focus:ring-0"
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[10px] text-zinc-500 border border-[#27272A] px-1.5 py-0.5 rounded-sm">
          <Command className="w-3 h-3" /> K
        </div>
      </div>

      <div className="flex-1" />

      {/* Theme */}
      <button
        data-testid={LAYOUT.themeToggle}
        onClick={toggleTheme}
        className="w-9 h-9 flex items-center justify-center border border-[#27272A] rounded-sm text-zinc-400 hover:text-white hover:border-[#3F3F46] transition-colors"
      >
        {isLight ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
      </button>

      {/* Notifications */}
      <NotificationPanel>
        <button
          data-testid={LAYOUT.headerNotifications}
          onClick={toggleNotifications}
          className="relative w-9 h-9 flex items-center justify-center border border-[#27272A] rounded-sm text-zinc-400 hover:text-white hover:border-[#3F3F46] transition-colors"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#E50914] text-[9px] text-white flex items-center justify-center rounded-full font-bold">5</span>
        </button>
      </NotificationPanel>

      {/* Profile */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            data-testid={LAYOUT.headerProfile}
            className="flex items-center gap-2.5 pl-1 pr-3 h-9 border border-[#27272A] rounded-sm hover:border-[#3F3F46] transition-colors"
          >
            <div className="w-7 h-7 rounded-sm bg-gradient-to-br from-[#E50914] to-[#7a0208] flex items-center justify-center text-[11px] font-bold text-white">
              {initials(user?.name)}
            </div>
            <div className="text-left leading-tight hidden sm:block">
              <div className="text-xs font-semibold text-white truncate max-w-[120px]">{user?.name || "Admin"}</div>
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest">{user?.role || "super-admin"}</div>
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56 bg-[#141414] border-[#27272A] text-white">
          <DropdownMenuLabel className="text-zinc-400 uppercase text-[10px] tracking-widest">Account</DropdownMenuLabel>
          <DropdownMenuItem className="focus:bg-[#1E1E1E] focus:text-white cursor-pointer" onClick={() => nav("/settings")}>
            <User className="w-4 h-4 mr-2" /> Profile
          </DropdownMenuItem>
          <DropdownMenuItem className="focus:bg-[#1E1E1E] focus:text-white cursor-pointer" onClick={() => nav("/change-password")}>
            <KeyRound className="w-4 h-4 mr-2" /> Change Password
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-[#27272A]" />
          <DropdownMenuItem
            data-testid={AUTH.logout}
            onClick={logout}
            className="focus:bg-[#1E1E1E] focus:text-[#E50914] text-[#E50914] cursor-pointer"
          >
            <LogOut className="w-4 h-4 mr-2" /> Sign Out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}

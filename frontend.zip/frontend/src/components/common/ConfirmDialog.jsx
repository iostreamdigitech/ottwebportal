import React from "react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "../../components/ui/alert-dialog";

export default function ConfirmDialog({ open, onOpenChange, title = "Are you sure?", description = "This action cannot be undone.", onConfirm, confirmText = "Confirm", destructive = true }) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-[#141414] border-[#27272A] text-white">
        <AlertDialogHeader>
          <AlertDialogTitle className="font-display uppercase tracking-wider">{title}</AlertDialogTitle>
          <AlertDialogDescription className="text-zinc-400">{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="bg-transparent border-[#27272A] text-white hover:bg-[#1E1E1E] hover:text-white">Cancel</AlertDialogCancel>
          <AlertDialogAction
            data-testid="confirm-dialog-confirm"
            onClick={onConfirm}
            className={destructive ? "bg-[#E50914] hover:bg-[#F40612] text-white" : "bg-white text-black hover:bg-zinc-200"}
          >
            {confirmText}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

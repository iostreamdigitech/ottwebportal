import React from "react";
import { cn } from "../../lib/utils";

export function PageHeader({ title, subtitle, actions, className }) {
  return (
    <div className={cn("flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6", className)}>
      <div>
        <h1 className="font-display uppercase text-3xl sm:text-4xl tracking-tight text-white leading-none">
          {title}
        </h1>
        {subtitle && (
          <p className="text-sm text-zinc-500 mt-2 max-w-2xl">{subtitle}</p>
        )}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export default PageHeader;

import React from "react";
import { Inbox } from "lucide-react";

export default function EmptyState({ title = "Nothing here yet", subtitle, action }) {
  return (
    <div className="border border-dashed border-[#27272A] rounded-sm p-12 text-center">
      <div className="w-12 h-12 mx-auto flex items-center justify-center bg-[#141414] border border-[#27272A] rounded-sm mb-4">
        <Inbox className="w-5 h-5 text-zinc-500" />
      </div>
      <div className="font-display uppercase tracking-widest text-white text-lg">{title}</div>
      {subtitle && <p className="text-sm text-zinc-500 mt-1">{subtitle}</p>}
      {action && <div className="mt-4 inline-flex">{action}</div>}
    </div>
  );
}

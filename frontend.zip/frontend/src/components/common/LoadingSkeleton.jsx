import React from "react";

export function TableSkeleton({ rows = 6, cols = 5 }) {
  return (
    <div className="border border-[#27272A] rounded-sm overflow-hidden">
      <div className="bg-[#141414] border-b border-[#27272A] p-3 flex gap-3">
        {[...Array(cols)].map((_, i) => (
          <div key={i} className="h-3 bg-[#1E1E1E] rounded-sm flex-1 animate-pulse" />
        ))}
      </div>
      {[...Array(rows)].map((_, r) => (
        <div key={r} className="border-b border-[#27272A] p-3 flex gap-3 last:border-0">
          {[...Array(cols)].map((__, c) => (
            <div key={c} className="h-3 bg-[#1E1E1E] rounded-sm flex-1 animate-pulse" style={{ opacity: 0.6 }} />
          ))}
        </div>
      ))}
    </div>
  );
}

export function GridSkeleton({ count = 8 }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {[...Array(count)].map((_, i) => (
        <div key={i} className="aspect-[2/3] bg-[#141414] border border-[#27272A] rounded-sm animate-pulse" />
      ))}
    </div>
  );
}

import React from "react";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown } from "lucide-react";
import * as Icons from "lucide-react";
import { formatCurrency, formatNumber } from "../../utils";
import { cn } from "../../lib/utils";

// Map icon key from backend to lucide component name
const iconAlias = {
  users: "Users",
  "user-check": "UserCheck",
  crown: "Crown",
  "indian-rupee": "IndianRupee",
  "trending-up": "TrendingUp",
  "bar-chart-3": "BarChart3",
  ticket: "Ticket",
  clock: "Clock",
  "monitor-smartphone": "MonitorSmartphone",
  film: "Film",
  tv: "Tv",
  "list-video": "ListVideo",
  radio: "Radio",
  languages: "Languages",
  tag: "Tag",
  "layout-grid": "LayoutGrid",
  "hard-drive": "HardDrive",
  cog: "Cog",
  "alert-triangle": "AlertTriangle",
  activity: "Activity",
};

export default function StatCard({ label, value, delta, icon, currency, index = 0 }) {
  const Icon = Icons[iconAlias[icon]] || Icons.Circle;
  const positive = (delta ?? 0) >= 0;
  const display = currency ? formatCurrency(value, currency) : formatNumber(value);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.02 * index, duration: 0.35 }}
      className="group relative bg-[#141414] border border-[#27272A] rounded-sm p-5 hover:border-[#3F3F46] transition-colors overflow-hidden"
    >
      <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-[#E50914]/5 opacity-0 group-hover:opacity-100 transition-opacity blur-2xl" />
      <div className="flex items-start justify-between mb-4 relative">
        <div className="w-9 h-9 flex items-center justify-center bg-[#1E1E1E] border border-[#27272A] rounded-sm">
          <Icon className="w-4 h-4 text-[#E50914]" strokeWidth={2} />
        </div>
        {delta !== undefined && delta !== 0 && (
          <div className={cn(
            "flex items-center gap-0.5 text-[10px] font-semibold uppercase tracking-widest",
            positive ? "text-emerald-500" : "text-red-500"
          )}>
            {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(delta)}%
          </div>
        )}
      </div>
      <div className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 mb-1 font-medium">
        {label}
      </div>
      <div className="font-display text-3xl text-white tracking-tight leading-none">
        {display}
      </div>
    </motion.div>
  );
}

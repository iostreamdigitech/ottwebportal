import React from "react";
import { cn } from "../../lib/utils";

const styles = {
  draft: "text-slate-400 bg-slate-500/10 border-slate-500/30",
  review: "text-amber-400 bg-amber-500/10 border-amber-500/30",
  approved: "text-sky-400 bg-sky-500/10 border-sky-500/30",
  published: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
  active: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
  archived: "text-zinc-500 bg-zinc-500/10 border-zinc-500/30",
  rejected: "text-red-400 bg-red-500/10 border-red-500/30",
  blocked: "text-red-400 bg-red-500/10 border-red-500/30",
  inactive: "text-zinc-500 bg-zinc-500/10 border-zinc-500/30",
  success: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
  failed: "text-red-400 bg-red-500/10 border-red-500/30",
  pending: "text-amber-400 bg-amber-500/10 border-amber-500/30",
};

export default function StatusBadge({ status = "draft" }) {
  const key = String(status || "").toLowerCase();
  const cls = styles[key] || styles.draft;
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2 py-0.5 border rounded-sm text-[10px] font-semibold uppercase tracking-[0.15em]",
      cls
    )}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {key}
    </span>
  );
}

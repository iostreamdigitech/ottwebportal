import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "../src/App.css";

import ProtectedRoute from "../src/routes/ProtectedRoute";
import AdminLayout from "./layouts/AdminLayout";

import Login from "../src/pages/auth/Login";
import ForgotPassword from "../src/pages/auth/ForgotPassword";
import OtpVerification from "../src/pages/auth/OtpVerification";
import ResetPassword from "../src/pages/auth/ResetPassword";
import ChangePassword from "../src/pages/auth/ChangePassword";

import Dashboard from "../src/pages/dashboard/Dashboard";
import UserList from "../src/pages/users/UserList";
import ContentList from "../src/pages/content/ContentList";
import ContentForm from "./pages/content/ContentForm";

import BannerList from "../src/pages/banners/BannerList";
import BannerForm from "./pages/banners/BannerForm";
import MasterList from "./pages/catalog/MasterList";
import SubscriptionPlans from "./pages/subscriptions/SubscriptionPlans";
import AdminUsers from "./pages/admin/AdminUsers";
import Roles from "../src/pages/admin/Roles";
import Settings from "./pages/settings/Settings";
import PlaceholderPage from "../src/pages/PlaceholderPage";

function App() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/login" element={<Login />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/verify-otp" element={<OtpVerification />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* Protected */}
      <Route
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/change-password" element={<ChangePassword />} />

        <Route path="/users" element={<UserList />} />

        <Route path="/content/:type" element={<ContentList />} />
        <Route path="/content/banners" element={<BannerList />} />
        <Route path="/content/banners/new" element={<BannerForm />} />
        <Route path="/content/banners/:id" element={<BannerForm />} />

        <Route path="/content/:type/:id" element={<ContentForm />} />

        <Route
          path="/catalog/categories"
          element={<MasterList resource="categories" />}
        />
        <Route
          path="/catalog/genres"
          element={<MasterList resource="genres" />}
        />
        <Route
          path="/catalog/languages"
          element={<MasterList resource="languages" />}
        />
        <Route
          path="/catalog/cast"
          element={<MasterList resource="cast" />}
        />
        <Route
          path="/catalog/crew"
          element={<MasterList resource="crew" />}
        />

        <Route path="/plans" element={<SubscriptionPlans />} />

        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/admin/roles" element={<Roles />} />

        <Route path="/settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default App;

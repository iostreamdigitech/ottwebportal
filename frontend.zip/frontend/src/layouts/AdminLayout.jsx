import React, { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Sidebar from "../components/layout/Sidebar.jsx";
import Header from "../components/layout/Header.jsx";
import Breadcrumb from "../components/layout/Breadcrumb.jsx";
import { useUiStore } from "../store/uiStore";
import { useAuthStore } from "../store/authStore";
import { cn } from "../lib/utils";
import { authService } from "../services";

export default function AdminLayout() {
  const { sidebarCollapsed } = useUiStore();
  const { isAuthenticated, setUser, reset } = useAuthStore();
  const nav = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      nav("/login");
      return;
    }
    // Refresh /me on layout mount
    authService.me().then(setUser).catch(() => {
      localStorage.removeItem("ott_token");
      reset();
      nav("/login");
    });
  }, []); // eslint-disable-line

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F5F5F1]">
      <Sidebar />
      <div className={cn("transition-[padding] duration-200", sidebarCollapsed ? "pl-[72px]" : "pl-[260px]")}>
        <Header />
        <main className="p-6 lg:p-8 max-w-[1600px]">
          <div className="mb-6">
            <Breadcrumb />
          </div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  );
}

const IS_STUB =
  String(import.meta.env.VITE_IS_STUB ?? "false").toLowerCase() === "true";

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "https://apiottone.ottone.in/api-gateway";

const API_BASE_URL = `${BACKEND_URL}`;

export { IS_STUB, BACKEND_URL, API_BASE_URL };
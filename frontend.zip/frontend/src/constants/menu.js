// Sidebar navigation config. Grouped by module.
import {
  LayoutDashboard, Users, Film, Tv, ListVideo, Tags, Layers, Languages,
  UserSquare2, Users2, CreditCard, ShieldCheck, KeyRound, Settings, Radio,
  PlaySquare, BookOpenText, HardDrive, Bell, LifeBuoy, BarChart3, Palette,
} from "lucide-react";
import { NAV } from "./testIds";

export const MENU = [
  {
    section: "Overview",
    items: [
      { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, to: "/dashboard", testid: NAV.dashboard },
    ],
  },
  {
    section: "Content",
    items: [
      { key: "banners", label: "Banners", icon: Film, to: "/content/banners", testid: NAV.banners },
      { key: "movies", label: "Movies", icon: Film, to: "/content/movies", testid: NAV.movies },
      { key: "series", label: "Series", icon: Tv, to: "/content/series", testid: NAV.series },
      { key: "episodes", label: "Episodes", icon: ListVideo, to: "/content/episodes", testid: NAV.episodes },
      { key: "live", label: "Live TV", icon: Radio, to: "/content/live" },
      { key: "shorts", label: "Short Videos", icon: PlaySquare, to: "/content/shorts" },
    ],
  },
  {
    section: "Catalog",
    items: [
      { key: "categories", label: "Categories", icon: Layers, to: "/catalog/categories", testid: NAV.categories },
      { key: "genres", label: "Genres", icon: Tags, to: "/catalog/genres", testid: NAV.genres },
      { key: "languages", label: "Languages", icon: Languages, to: "/catalog/languages", testid: NAV.languages },
      { key: "cast", label: "Cast", icon: UserSquare2, to: "/catalog/cast", testid: NAV.cast },
      { key: "crew", label: "Crew", icon: Users2, to: "/catalog/crew", testid: NAV.crew },
    ],
  },
  {
    section: "Audience",
    items: [
      { key: "users", label: "Customers", icon: Users, to: "/users", testid: NAV.users },
      { key: "notifications", label: "Notifications", icon: Bell, to: "/notifications" },
      { key: "support", label: "Support", icon: LifeBuoy, to: "/support" },
    ],
  },
  {
    section: "Billing",
    items: [
      { key: "plans", label: "Subscription Plans", icon: CreditCard, to: "/plans", testid: NAV.plans },
      { key: "reports", label: "Reports", icon: BarChart3, to: "/reports" },
    ],
  },
  {
    section: "System",
    items: [
      { key: "admins", label: "Admin Users", icon: ShieldCheck, to: "/admin/users", testid: NAV.admins },
      { key: "roles", label: "Roles & Permissions", icon: KeyRound, to: "/admin/roles", testid: NAV.roles },
      { key: "media", label: "Media Library", icon: HardDrive, to: "/media" },
      { key: "branding", label: "Branding", icon: Palette, to: "/settings/branding" },
      { key: "settings", label: "Settings", icon: Settings, to: "/settings", testid: NAV.settings },
      { key: "audit", label: "Audit Logs", icon: BookOpenText, to: "/audit" },
    ],
  },
];

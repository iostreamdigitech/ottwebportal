// Central catalog of data-testid values used across the app.
// kebab-case, role-based naming.

export const AUTH = {
  loginEmail: "login-email-input",
  loginPassword: "login-password-input",
  loginSubmit: "login-submit-button",
  loginRemember: "login-remember-toggle",
  forgotLink: "login-forgot-link",
  forgotEmail: "forgot-email-input",
  forgotSubmit: "forgot-submit-button",
  otpInput: "otp-code-input",
  otpSubmit: "otp-submit-button",
  resetPassword: "reset-password-input",
  resetConfirm: "reset-confirm-input",
  resetSubmit: "reset-submit-button",
  changeOld: "change-old-password-input",
  changeNew: "change-new-password-input",
  changeSubmit: "change-submit-button",
  logout: "logout-button",
};

export const LAYOUT = {
  sidebar: "app-sidebar",
  sidebarToggle: "sidebar-toggle-button",
  headerSearch: "header-global-search",
  headerNotifications: "header-notifications-button",
  headerProfile: "header-profile-button",
  themeToggle: "header-theme-toggle",
};

export const NAV = {
  dashboard: "nav-dashboard",
  users: "nav-users",
 banners: "nav-banners",
  movies: "nav-movies",
  series: "nav-series",
  episodes: "nav-episodes",
  categories: "nav-categories",
  genres: "nav-genres",
  languages: "nav-languages",
  cast: "nav-cast",
  crew: "nav-crew",
  plans: "nav-plans",
  admins: "nav-admins",
  roles: "nav-roles",
  settings: "nav-settings",
};

export const HOME = { emergentLink: "home-emergent-link" };

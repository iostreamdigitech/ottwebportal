import { create } from "zustand";
import { persist } from "zustand/middleware";

export const useAuthStore = create(
  persist(
    (set) => ({
      token: null,
      user: null,
      isAuthenticated: false,
      setSession: ({ token, user }) => set({ token, user, isAuthenticated: !!token }),
      setUser: (user) => set({ user }),
      reset: () => set({ token: null, user: null, isAuthenticated: false }),
    }),
    {
      name: "ott-auth",
      partialize: (s) => ({ token: s.token, user: s.user, isAuthenticated: s.isAuthenticated }),
    }
  )
);

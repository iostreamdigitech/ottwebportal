import { create } from "zustand";

export const useUiStore = create((set) => ({
  sidebarCollapsed: false,
  notificationsOpen: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
  toggleNotifications: () => set((s) => ({ notificationsOpen: !s.notificationsOpen })),
}));

import api from "./api";
import { initSessionKeys, clearSessionKeys, invalidatePublicKeyCache } from './cryptoService';
const BASE = 'http://localhost:8080/api-gateway';
const cfg  = { baseURL: BASE };
export const authService = {
  
  async loginnew(credentials) {
  
    // Establish the RSA public key + AES session key once at login (mirrors LoginTest.java)
    await initSessionKeys();

    try {
      console.log('[Auth] Sending login request for:', credentials.email);
      const response = await api.post('/iam/api/users/auth/login', credentials);
      console.log('[Auth] Raw login response:', response);

      // API wraps payload: { success, data: { token, user, ... } }
      const payload = response?.data || response;
      console.log('[Auth] Extracted payload:', payload);

      const token = payload?.token || payload?.accessToken;
      console.log('[Auth] Extracted token:', token ? `${token.slice(0, 20)}...` : 'NOT FOUND');

      const user = payload?.user || null;
      console.log('[Auth] Extracted user:', user);

      if (token) localStorage.setItem('ott_token', token);
      return { token, user };
    } catch (err) {
      console.error('[Auth] Login error:', err);
      // Stale cached key — invalidate so the next attempt fetches a fresh one
      if (err?.responseCode === '401') invalidatePublicKeyCache();
      throw err;
    }
  },
  login: (payload) => api.post("/iam/api/users/auth/login", payload),
  me: () => api.get("/iam/api/users/me"),
  forgotPassword: (email) => api.post("/auth/forgot-password", { email }),
  verifyOtp: (email, otp) => api.post("/auth/verify-otp", { email, otp }),
  resetPassword: (email, otp, new_password) =>
    api.post("/auth/reset-password", { email, otp, new_password }),
  changePassword: (old_password, new_password) =>
    api.post("/auth/change-password", { old_password, new_password }),
};

export const dashboardService = {
  stats: () => api.get("/dashboard/stats"),
  charts: () => api.get("/dashboard/charts"),
  recent: () => api.get("/dashboard/recent"),
};

export const userService = {

  list: async (params) => {
  const response = await api.get("/iam/api/users/customers", {
    params,
  });

  const result = response.data.data;

  return {
    items: result || [],
    total: result.totalRecords || 0,
    pages: result.totalPages || 1,
    page: result.page || 1,
    pageSize: result.pageSize || 12
  };
},

 
  get: (id) => api.get(`/users/${id}`),
  create: (b) => api.post("/users", b),
  update: (id, b) => api.put(`/users/${id}`, b),
  delete: (id) => api.delete(`/users/${id}`),
  bulk: (ids, action) => api.post("/users/bulk", { ids, action }),
};

export const bannerService = {

  async getAllBanners() {
     console.log("Calling Banner API...");


    return api.get("/contentservice/api/banners");
  },

  async getBannerById(id) {
   

    return api.get(`/contentservice/api/banners/${id}`);
  },

  async createBanner(files, metadata) {

    const formData = new FormData();

    formData.append(
      "request",
      new Blob(
        [JSON.stringify(metadata)],
        { type: "application/json" }
      )
    );

    if (files.desktopImage) {
      formData.append("desktopImage", files.desktopImage);
    }

    if (files.mobileImage) {
      formData.append("mobileImage", files.mobileImage);
    }

    if (files.tvImage) {
      formData.append("tvImage", files.tvImage);
    }

    if (files.backgroundVideo) {
      formData.append(
        "backgroundVideo",
        files.backgroundVideo
      );
    }

    return api.post(
      "/contentservice/api/banners",
      formData,
      {
        ...cfg,
        headers: {
          "Content-Type": undefined,
        },
      }
    );
  },

  async updateBanner(id, files, metadata) {

    const formData = new FormData();

    formData.append(
      "request",
      new Blob(
        [JSON.stringify(metadata)],
        { type: "application/json" }
      )
    );

    if (files.desktopImage) {
      formData.append("desktopImage", files.desktopImage);
    }

    if (files.mobileImage) {
      formData.append("mobileImage", files.mobileImage);
    }

    if (files.tvImage) {
      formData.append("tvImage", files.tvImage);
    }

    if (files.backgroundVideo) {
      formData.append(
        "backgroundVideo",
        files.backgroundVideo
      );
    }

    return api.put(
      `/contentservice/api/banners/${id}`,
      formData,
      {
        ...cfg,
        headers: {
          "Content-Type": undefined,
        },
      }
    );
  },

  async deleteBanner(id) {
   
    return api.delete(
      `/contentservice/api/banners/${id}`
    );
  },

};

export const contentServiceData = {
 async getAllContentType() {
   const res = await api.get( "/contentservice/api/v1/content-types" ); 
   console.log("allcon", res.data) 
   return res.data; 
  },
  async getAllGeneres()
   { 
      const res = await api.get('/contentservice/api/v1/genres', cfg); 
      return res.data; 
    
    }, 
    async getAllLanguages()
    { 
     const res = await api.get('/contentservice/api/v1/languages', cfg); 
     return res.data; 
    },
  async getAllCategories() {
    
      const res = await api.get('/contentservice/api/v1/categories', cfg); 
      return res.data; 
    },
};


export const contentService = {
  list: ({ type, page = 0, size = 60, sort = "createdDate,desc", q, status }) =>
  api.get(`/contentservice/api/v1/content/type/${type}`, {
    params: {
      page,
      size,
      q,
      status,
    },
  }),
  get: (id) => api.get(`/contentservice/api/v1/content/${id}`),
  create: (b) => api.post("/contentservice/api/v1/content", b),
uploadAssets: async (contentId, assets) => {

    const metadata = {
        contentId,
        assets: assets.map(asset => ({
            platform: asset.platform,
            assetType: asset.assetType
        }))
    };

    const formData = new FormData();

    formData.append(
        "data",
        new Blob(
            [JSON.stringify(metadata)],
            { type: "application/json" }
        )
    );

    assets.forEach(asset => {
        if (asset.file) {
            formData.append("files", asset.file);
        }
    });

    return api.post(
        "/contentservice/api/media/upload",
        formData,
        {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        }
    );
},
  update: (id, b) => api.put(`/content/${id}`, b),
  delete: (id) => api.delete(`/content/${id}`),
  changeStatus: (id, status) => api.post(`/content/${id}/status`, { status }),
};


const cast = (path) => ({

    list: async () => {
    const response = await api.get(
     `/${path}`
    );

    return response.data.content || [];
  },


  create: (b) => api.post(`/${path}`, b),
  update: (id, b) => api.put(`/${path}/${id}`, b),
  delete: (id) => api.delete(`/${path}/${id}`),
});
const master = (path) => ({

    list: async () => {
    const response = await api.get(
     `/${path}`
    );

    return response.data || [];
  },


  create: (b) => api.post(`/${path}`, b),
  update: (id, b) => api.put(`/${path}/${id}`, b),
  delete: (id) => api.delete(`/${path}/${id}`),
});

export const categoryService = master("contentservice/api/v1/categories");
export const genreService = master("contentservice/api/v1/genres");
export const languageService = master("contentservice/api/v1/languages");
export const castService = cast("contentservice/api/cast");
export const crewService = master("crew");

export const planService = {
  list: () => api.get("/payService/api/subscription-plans"),
  create: (b) => api.post("/payService/api/subscription-plans", b),
  update: (id, b) => api.put(`/payService/api/subscription-plans/${id}`, b),
  delete: (id) => api.delete(`/payService/api/subscription-plans/${id}`),
};

export const pricingService = {
  list: () => api.get("/payService/api/v1/pricing"),
  create: (b) => api.post("/payService/api/v1/pricing", b),
  update: (id, b) => api.put(`/payService/api/v1/pricing/${id}`, b),
  delete: (id) => api.delete(`/payService/api/v1/pricing/${id}`),
};


export const adminService = {

  listUsers: async () => {
    const response = await api.get(
      "/iam/api/users/admin/adminUsers"
    );

    return response.data || [];
  },


  listRoles: async () => {
    const response = await api.get(
      "/iam/api/admin/roles"
    );

    return response.data.data || [];
  },


};

export const settingsService = {
  get: () => api.get("/settings"),
  update: (section, values) => api.put("/settings", { section, values }),
};

export const notificationService = {
  list: () => api.get("/notifications"),
};

/**
 * Crypto utilities for OTT Gateway security protocol.
 *
 * Flow (mirrors LoginTest.java → EncryptionService.java + PublicKeyApiTest.java):
 *   1. initSessionKeys()                 — called once at login: fetches RSA-4096 public key AND
 *                                          generates a single AES-256 session key for the app session
 *   2. encryptPayload(data)              — encrypts body with the session AES key (RSA-OAEP wrapped)
 *   3. buildHmacHeaders(uri, bodyBytes)  — signs every request (HMAC-SHA256 over encrypted body)
 *   4. clearSessionKeys()                — called on logout to wipe both cached keys
 *
 * Configure via Vite env vars (VITE_GATEWAY_URL, VITE_API_TOKEN, VITE_SECRET_KEY, VITE_CHANNEL).
 */

const GATEWAY_URL         = import.meta.env.VITE_GATEWAY_URL         || 'http://localhost:8080/api-gateway';
const GATEWAY_PATH_PREFIX = import.meta.env.VITE_GATEWAY_PATH_PREFIX || '/api-gateway';
const API_TOKEN           = import.meta.env.VITE_API_TOKEN           || 'dev-api-token-001';
const SECRET_KEY          = import.meta.env.VITE_SECRET_KEY          || 'd3vHmacS3cretK3yVal1d4t10nX9ZpQ7';
const CHANNEL             = import.meta.env.VITE_CHANNEL             || 'WEB';

// { cryptoKey: CryptoKey, keyId: string, expiry: Date } | null
let _keyCache = null;

// AES-256-GCM session key — generated once at login, reused for the entire app session
let _sessionAesKey = null;

// ── Internal helpers ────────────────────────────────────────────────────────

async function sha256Hex(data) {
  const bytes = data instanceof Uint8Array ? data : new TextEncoder().encode(data);
  const buf   = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function hmacSha256Base64(secretKey, message) {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secretKey),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message));
  return bufToBase64(sig);
}

function bufToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary  = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

// ── Public API ──────────────────────────────────────────────────────────────

/**
 * Build the five HMAC security headers required by HmacValidationFilter.
 *
 * @param {string}     requestUri  Full URI path as seen by the gateway
 *                                 (e.g. '/api-gateway/auth/login')
 * @param {Uint8Array} [bodyBytes] Raw request body bytes (empty for GET requests)
 */
export async function buildHmacHeaders(requestUri, bodyBytes = new Uint8Array(0)) {
  const timestamp   = String(Math.floor(Date.now() / 1000));
  const nonce       = Array.from(crypto.getRandomValues(new Uint8Array(8)))
                        .map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
  const requestHash = await sha256Hex(bodyBytes);

  // signature = Base64(HMAC-SHA256(secretKey, apiToken+channel+requestUri+timestamp+nonce+requestHash))
  const message   = API_TOKEN + CHANNEL + requestUri + timestamp + nonce + requestHash;
  const signature = await hmacSha256Base64(SECRET_KEY, message);

  return { apiToken: API_TOKEN, channel: CHANNEL, timestamp, nonce, signature };
}

/**
 * Fetch and cache the gateway's RSA-4096 public key.
 * Matches GET /gateway/security/public-key from SecurityController.java.
 *
 * @returns {{ cryptoKey: CryptoKey, keyId: string, expiry: Date }}
 */
export async function fetchPublicKey() {
  if (_keyCache && _keyCache.expiry > new Date()) return _keyCache;

  const requestUri = `${GATEWAY_PATH_PREFIX}/gateway/security/public-key`;
  const headers    = await buildHmacHeaders(requestUri);

  const res = await fetch(`${GATEWAY_URL}/gateway/security/public-key`, {
    method:  'GET',
    headers: { 'Content-Type': 'application/json', ...headers },
  });

  if (!res.ok) {
    throw new Error(`Public key fetch failed: ${res.status} ${res.statusText}`);
  }

  // { keyId, algorithm, publicKey (Base64 SPKI DER), expiry (ISO local datetime) }
  const data = await res.json();

  // Normalize: strip PEM headers/whitespace, convert Base64URL → standard Base64, re-pad
  const b64 = data.publicKey
    .replace(/-----[^-]+-----/g, '')   // strip PEM header/footer if present
    .replace(/\s+/g, '')               // strip whitespace / newlines
    .replace(/-/g, '+')                // Base64URL → Base64
    .replace(/_/g, '/');               // Base64URL → Base64
  const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
  const derBytes  = Uint8Array.from(atob(padded), c => c.charCodeAt(0));
  const cryptoKey = await crypto.subtle.importKey(
    'spki',
    derBytes,
    { name: 'RSA-OAEP', hash: 'SHA-256' },
    false,
    ['encrypt'],
  );

  _keyCache = { cryptoKey, keyId: data.keyId, expiry: new Date(data.expiry) };
  return _keyCache;
}

/**
 * Initialize both session keys at login time (mirrors LoginTest.java).
 * Fetches the RSA public key and generates one AES-256 session key that will be
 * reused for every encrypted request until clearSessionKeys() is called.
 */
export async function initSessionKeys() {
  await fetchPublicKey();

  if (!_sessionAesKey) {
    _sessionAesKey = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt'], // 'decrypt' needed to unwrap encrypted server responses
    );
    console.log('[Crypto] Session AES-256-GCM key generated');
  }
}

/**
 * Wipe the public key cache and AES session key (call on logout).
 */
export function clearSessionKeys() {
  _keyCache      = null;
  _sessionAesKey = null;
}

/**
 * Encrypt a JSON payload using the AES-256-GCM session key wrapped by RSA-4096-OAEP.
 * Mirrors the client-side counterpart of EncryptionService.decryptRequest() on the server.
 * The session AES key is established once at login via initSessionKeys(); each call uses
 * a fresh 12-byte IV so GCM nonces are never reused.
 *
 * @param {object|string} payload  Data to encrypt (will be JSON-stringified if object)
 * @returns {{ encryptedKey: string, encryptedData: string, iv: string, keyId: string }}
 *          All byte fields are Base64-encoded strings (EncryptedPayload model).
 */
export async function encryptPayload(payload) {
  const { cryptoKey, keyId } = await fetchPublicKey();

  // Use the session AES key if already established; fall back to a fresh ephemeral key
  // if encryptPayload is called before initSessionKeys() (e.g. the login request itself).
  let aesKey = _sessionAesKey;
  if (!aesKey) {
    aesKey = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt'],
    );
  }

  // Fresh 12-byte IV per call (matches GCM_IV_LENGTH = 12 in EncryptionService.java)
  const iv = crypto.getRandomValues(new Uint8Array(12));

  // AES-256-GCM encrypt (Web Crypto appends 128-bit auth tag, matching GCM_TAG_LENGTH = 128)
  const plainBytes    = new TextEncoder().encode(
    typeof payload === 'string' ? payload : JSON.stringify(payload),
  );
  const encryptedData = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, tagLength: 128 },
    aesKey,
    plainBytes,
  );

  // RSA-OAEP (SHA-256 + MGF1-SHA256) wrap the AES key — sent with every request so the
  // server can unwrap it using the private key (matching EncryptionService.decryptRequest)
  const rawAes       = await crypto.subtle.exportKey('raw', aesKey);
  const encryptedKey = await crypto.subtle.encrypt({ name: 'RSA-OAEP' }, cryptoKey, rawAes);

  return {
    encryptedKey:  bufToBase64(encryptedKey),
    encryptedData: bufToBase64(encryptedData),
    iv:            bufToBase64(iv),
    keyId,
  };
}

/** Invalidate the cached public key (e.g. on a 401 decryption failure). */
export function invalidatePublicKeyCache() {
  _keyCache = null;
}

/**
 * Decrypt a server response envelope produced by EncryptionService.java.
 *
 * Shape: { encryptedKey: null | string, encryptedData: string, iv: string, keyId: string }
 *
 * When encryptedKey is null the server re-used the session AES key we sent at login.
 * iv and encryptedData are standard Base64 strings.
 */
export async function decryptResponse({ encryptedData, iv, keyId }) {
  console.log('[Crypto] decryptResponse called — keyId:', keyId);
  if (!_sessionAesKey) {
    console.log("[Crypto] Session key missing. Reinitializing...");
    await initSessionKeys();
  }
  if (!_sessionAesKey) {
    throw new Error('[Crypto] Session AES key not available — call initSessionKeys() first');
  }

  const ivBytes   = Uint8Array.from(atob(iv),            c => c.charCodeAt(0));
  const dataBytes = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));

  console.log('[Crypto] IV length:', ivBytes.length, 'Data length:', dataBytes.length);

  const decryptedBuf = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: ivBytes, tagLength: 128 },
    _sessionAesKey,
    dataBytes,
  );

  const text = new TextDecoder().decode(decryptedBuf);
  console.log('[Crypto] Decrypted response text:', text);

  return JSON.parse(text);
}

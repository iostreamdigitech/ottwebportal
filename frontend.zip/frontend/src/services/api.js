import axios from 'axios';
import { API_BASE_URL, IS_STUB } from '../constants/stub';
import { buildHmacHeaders, encryptPayload, decryptResponse } from './cryptoService';



const ENCRYPT_METHODS = new Set(['post', 'put', 'patch']);

/**
 * Compute the URI path that the gateway will see for this request.
 * Matches exchange.getRequest().getURI().getPath() used by HmacValidationFilter.java.
 */
function getRequestPath(config) {
  const base = (config.baseURL || API_BASE_URL).replace(/\/$/, '');
  const path = (config.url || '').replace(/^\//, '');
  try {
    return new URL(`${base}/${path}`).pathname;
  } catch {
    return `/${path}`;
  }
}

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

// 1. Attach Bearer token from localStorage
api.interceptors.request.use((config) => {
  const raw = localStorage.getItem('ott_token');
  // Guard against stale "undefined" / "null" strings written by earlier bugs
  const token = raw && raw !== 'undefined' && raw !== 'null' ? raw : null;
  if (!token) localStorage.removeItem('ott_token'); // clean up corrupted entry
  if (token) config.headers.Authorization = `Bearer ${token}`;



  return config;
});

// 2. Encrypt body (POST/PUT/PATCH) + add HMAC security headers
api.interceptors.request.use(async (config) => {
  if (IS_STUB) return config;

  const method     = (config.method || 'get').toLowerCase();
  const requestUri = getRequestPath(config);
  let bodyBytes    = new Uint8Array(0);

  if (ENCRYPT_METHODS.has(method) && config.data != null) {
    if (config.data instanceof FormData) {
      // Multipart / file-upload: never encrypt — the gateway passes multipart streams through
      // untouched (BodyCachingFilter sets ATTR_IS_MULTIPART and skips body caching).
      // HMAC uses SHA-256(empty bytes) on both sides: the gateway's HmacValidationFilter reads
      // ATTR_CACHED_BODY which is null for multipart, so it hashes new byte[0] — same as here.
      // Leave config.data and Content-Type untouched so the browser auto-sets the boundary.
    } else {

        console.group(`🔐 API Request: ${method.toUpperCase()} ${requestUri}`);
    console.log("Plain Request:", config.data);
    console.log("JSON:", JSON.stringify(config.data, null, 2));
    console.groupEnd();
      // JSON / plain body: encrypt and forward as application/json EncryptedPayload envelope.
      const encrypted     = await encryptPayload(config.data);
      const encryptedJson = JSON.stringify(encrypted);
      config.data                       = encryptedJson;
      config.headers['Content-Type']    = 'application/json';
      bodyBytes = new TextEncoder().encode(encryptedJson);
    }
  }

  // requestHash = SHA-256(bodyBytes), signature = Base64(HMAC-SHA256(secret, ...+requestHash))
  const hmacHeaders = await buildHmacHeaders(requestUri, bodyBytes);
  Object.assign(config.headers, hmacHeaders);

  return config;
});

api.interceptors.response.use(
  async (res) => {
    const raw = res.data;

    if (!IS_STUB && raw && raw.encryptedData && raw.iv) {
      try {
        const decrypted = await decryptResponse(raw);
        return decrypted;
      } catch (decryptErr) {
        throw decryptErr;
      }
    }

    return raw;
  },
  (err) => {
    console.error(`[API] Error ${err.response?.status} ${err.config?.url}`, {
      status: err.response?.status,
      data: err.response?.data,
      message: err.message,
    });

    const status = err.response?.status;

    if (status === 401 || status === 403) {
      // Clear everything
      localStorage.clear();
      sessionStorage.clear();

      // Redux logout
    

      // Force redirect to login page
      window.location.href = '/';
    }

    return Promise.reject(err.response?.data || err.message);
  }
);

export default api;
